# NS Street

Sakarya sokaklarında geçen, telefonda oynanan Most Wanted tarzı yarış oyunu.

- Kariyer: sürücü profili, rütbe, para, görevler, garaj ve yükseltmeler
- Polis kovalamacası: sollama, yol kesme, barikat, ısı seviyesi
- Arkadaşla kapış: 4 haneli kodla bağlanıp 1'e 1 yarış (internet gerekir)

Tarayıcıdan oyna: GitHub Pages linki · Android: Actions sekmesindeki son derlemeden `NS-Street-APK`

Araç modelleri Sketchfab sanatçılarına aittir (CC lisansları, ticari kullanım yoktur).
