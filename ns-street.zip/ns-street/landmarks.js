// [AJAN:landmarks] Akasya Sk. / Şehit Ahmet Akyol Sk. kavşağı — Street View fotoğraflarına göre özel modeller.
// osmdata.js'den SONRA, ana script'ten ÖNCE yüklenir. Ana script'in iç değişkenlerine erişmez; LM.build(ctx) ile gerekenler verilir.
// Yükleme anında: kavşak landmark alanlarındaki prosedürel ev/apartman/park araba/ağaçları filtreler, Akasya Sk. evlerini fotoğraflardaki tiplere çevirir.
var LM=(function(){
'use strict';
// ---- kavşak çerçevesi (pist index 0 = kavşak): a = pist ileri (KB, köprüye doğru), l = pist sol (GB)
var J=[14.507,-311.609],T=[-0.8,-0.6],Lv=[-0.6,0.8];
function W(a,l){return [J[0]+T[0]*a+Lv[0]*l,J[1]+T[1]*a+Lv[1]*l]}
function AL(x,z){var dx=x-J[0],dz=z-J[1];return [dx*T[0]+dz*T[1],dx*Lv[0]+dz*Lv[1]]}
var sd=90210;function rnd(){sd|=0;sd=sd+0x6D2B79F5|0;var t=Math.imul(sd^sd>>>15,1|sd);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}
function pick(a){return a[Math.floor(rnd()*a.length)]}
// landmark alanları [a0,a1,l0,l1]: cami, çay ocağı, eczane, market
var EX=[[-47,-5.6,11.6,47],[5.6,31,11.6,35],[5.6,25,-28,-11.6],[-37,-5.6,-29,-11.6]];
function inEx(x,z,pad){var q=AL(x,z);for(var i=0;i<EX.length;i++){var e=EX[i];if(q[0]>e[0]-pad&&q[0]<e[1]+pad&&q[1]>e[2]-pad&&q[1]<e[3]+pad)return true}return false}
// sokak eksenleri (OSM)
var AK=[[-31,-247],[15,-312],[18,-317],[48,-359],[120,-464],[153,-511]],SA=[[-230,-383],[-32,-342],[-25.5,-343.8],[-9.4,-334.2],[14.5,-311.6],[45,-289.5],[68,-275]];
function segD(x,z,P){var b=1e9;for(var i=0;i<P.length-1;i++){var a=P[i],c=P[i+1],ex=c[0]-a[0],ez=c[1]-a[1],L=ex*ex+ez*ez,t=Math.max(0,Math.min(1,((x-a[0])*ex+(z-a[1])*ez)/L)),dx=a[0]+ex*t-x,dz=a[1]+ez*t-z;b=Math.min(b,dx*dx+dz*dz)}return Math.sqrt(b)}

// ================= 1) VERİ ÖN İŞLEME (yükleme anında) =================
var ZH=[],ZB=[];
(function(){if(typeof OSMD==='undefined')return;
 OSMD.houses=OSMD.houses.filter(function(h){return !inEx(h[0],h[1],Math.max(h[4],h[5])/2+h[11]*.6)});
 OSMD.boxes=OSMD.boxes.filter(function(b){return !inEx(b[0],b[1],Math.max(b[4],b[5])/2+.5)});
 OSMD.parked=OSMD.parked.filter(function(p){return !inEx(p[0],p[1],2)&&!(Math.abs(AL(p[0],p[1])[0]-38)<14&&Math.abs(AL(p[0],p[1])[1])<16)});
 OSMD.trees=OSMD.trees.filter(function(t){return !inEx(t[0],t[1],1.5)});
 OSMD.bins=OSMD.bins.filter(function(b){return !inEx(b[0],b[1],1)});
 // Akasya Sk. + Ş.A.Akyol Sk. boyunca (kavşağa ~260 m) evleri fotoğraf tiplerine çevir
 OSMD.houses.forEach(function(h){var dj=Math.hypot(h[0]-J[0],h[1]-J[1]);if(dj>265)return;
  var ds=Math.min(segD(h[0],h[1],AK),segD(h[0],h[1],SA));if(ds>34)return;
  var r=rnd(),ty;
  if(r<.27){ty=1;h[6]=rnd()<.55?3:4;h[7]=pick([8,8,3,12]);h[8]=0;h[9]=0;h[14]=1.6}          // turuncu/hardal balkonlu apartman
  else if(r<.57){ty=2;h[6]=rnd()<.6?2:3;h[7]=pick([0,4,10,2,0]);h[8]=1;h[14]=2.7}            // gri trapez sac çatılı, geniş saçaklı
  else if(r<.68){ty=3;h[6]=rnd()<.5?2:3;h[7]=6;h[8]=1;h[14]=2.2}                             // bej yatay siding
  else if(r<.84){ty=4;h[6]=rnd()<.5?2:3;h[7]=9;h[8]=0;h[14]=1.5}                             // somon pembe
  else{ty=5;h[6]=rnd()<.6?1:2;h[7]=pick([11,0,9]);h[8]=0;h[14]=1.3}                          // eski tek-iki katlı, asmalı
  h[13]=rnd()<.68?0:1;h[15]=ty;ZH.push(h)});
 // Akasya boyundaki apartman blokları: kırma çatı, dükkânsız, fotoğraftaki renkler, balkon (build'de)
 OSMD.boxes.forEach(function(b){var dj=Math.hypot(b[0]-J[0],b[1]-J[1]);if(dj>265)return;var ds=Math.min(segD(b[0],b[1],AK),segD(b[0],b[1],SA));if(ds>36)return;
  b[6]=Math.min(b[6],rnd()<.5?12:9);b[7]=pick([4,1,3,4,2]);b[8]=1;b[9]=0;ZB.push(b)});
})();

// ================= 2) DOKU ATLASI =================
var AW=2048,AH=1024,RG={
 MOSG:[0,0,1024,200],MOSU:[0,200,1024,300],MOSD:[0,500,1024,96],
 ECZU:[1024,0,512,384],ECZG:[1024,384,512,128],ECZS:[1024,656,512,384-16],
 MKT:[1536,0,512,192],MKTS:[1792,192,256,160],KHV:[1024,512,512,136],
 AWN:[1536,192,256,64],S_ECZ:[1536,256,256,64],S_MKT:[1536,320,256,64],S_CAY:[1792,352,256,64],
 ONEW:[1536,384,64,64],S_E:[1600,384,64,64],IST:[1664,384,128,40],
 MELON:[1536,448,64,64],CRATE:[1600,448,64,64],WHITE:[1668,452,24,24],WDIM:[1700,452,24,24],GRAYP:[1732,452,24,24],WOOD:[1764,452,24,24],
 CUMBA:[1536,512,256,128],TILE:[1792,512,256,256],DORM:[1536,640,128,96],PAV:[1664,640,128,128]};
var XW=1024,XH=256,XR={RAIL:[0,0,256,64],BALU:[256,0,256,64],LATT:[512,0,256,64],SCAL:[768,0,256,32],WIRE:[768,32,256,32]};
function uvR(r,inset,isX){var w=isX?XW:AW,h=isX?XH:AH,i=inset===undefined?1.5:inset;return [(r[0]+i)/w,1-(r[1]+r[3]-i)/h,(r[0]+r[2]-i)/w,1-(r[1]+i)/h]}
function sub(r,u0,v0,u1,v1){return [r[0]+(r[2]-r[0])*u0,r[1]+(r[3]-r[1])*v0,r[0]+(r[2]-r[0])*u1,r[1]+(r[3]-r[1])*v1]}
function cv(w,h){var c=document.createElement('canvas');c.width=w;c.height=h;return c}
function nz(g,x,y,w,h,base,amp){g.fillStyle=base;g.fillRect(x,y,w,h);var id=g.getImageData(x,y,w,h),d=id.data;for(var i=0;i<d.length;i+=4){var n=(rnd()-.5)*amp;d[i]+=n;d[i+1]+=n;d[i+2]+=n}g.putImageData(id,x,y)}
function stains(g,x,y,w,h,n,dark){for(var i=0;i<n;i++){g.fillStyle='rgba('+(dark?'40,36,30':'255,255,255')+','+(.03+rnd()*.05)+')';var sw=4+rnd()*w*.08;g.fillRect(x+rnd()*w,y+rnd()*h*.5,sw,h*(.2+rnd()*.5))}}
function arch(g,x,y,w,h){g.beginPath();g.moveTo(x,y+h);g.lineTo(x,y+w/2);g.arc(x+w/2,y+w/2,w/2,Math.PI,0);g.lineTo(x+w,y+h);g.closePath()}
function glassG(g,x,y,w,h){var gr=g.createLinearGradient(x,y,x+w*.5,y+h);gr.addColorStop(0,'#a8bccb');gr.addColorStop(.5,'#46525e');gr.addColorStop(1,'#232a31');return gr}
function txt(g,s,x,y,sz,col,font){g.fillStyle=col;g.font=(font||'bold')+' '+sz+'px Arial';g.textAlign='center';g.textBaseline='middle';g.fillText(s,x,y)}
function starLattice(g,x,y,w,h,s,col,lw){g.save();g.strokeStyle=col;g.lineWidth=lw;
 for(var yy=y+s/2;yy<y+h+s;yy+=s)for(var xx=x+s/2;xx<x+w+s;xx+=s){var r=s*.36;g.strokeRect(xx-r,yy-r,2*r,2*r);g.beginPath();g.moveTo(xx,yy-r*1.42);g.lineTo(xx+r*1.42,yy);g.lineTo(xx,yy+r*1.42);g.lineTo(xx-r*1.42,yy);g.closePath();g.stroke()}
 g.restore()}
function pvcWin(g,e,x,y,w,h,lit){g.fillStyle='#f3f3f0';g.fillRect(x-4,y-4,w+8,h+8);g.fillStyle=glassG(g,x,y,w,h);g.fillRect(x,y,w,h);
 if(rnd()<.7){g.fillStyle='rgba(236,229,212,'+(.4+rnd()*.35)+')';g.fillRect(x,y,w*.28,h);g.fillRect(x+w*.72,y,w*.28,h)}
 g.fillStyle='#f3f3f0';g.fillRect(x+w/2-2,y,4,h);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(x-5,y+h+4,w+10,3);
 if(e&&(lit||rnd()<.35)){e.fillStyle=rnd()<.6?'#ffcf86':'#f0b070';e.fillRect(x,y,w,h)}}
var ATL=null;
function atlas(){if(ATL)return ATL;var c=cv(AW,AH),g=c.getContext('2d'),ec=cv(AW,AH),e=ec.getContext('2d'),r,i,x,y,k;
 g.fillStyle='#bbb';g.fillRect(0,0,AW,AH);e.fillStyle='#000';e.fillRect(0,0,AW,AH);
 // --- Cami zemin katı: açık mavi-gri sıva, seramik karo etek, kemerli pencereler
 r=RG.MOSG;nz(g,r[0],r[1],r[2],r[3],'#a4b1c6',9);stains(g,r[0],r[1],r[2],r[3],30,true);
 e.fillStyle='#3a4250';e.fillRect(r[0],r[1],r[2],r[3]);
 var dT=r[1]+r[3]-58;for(y=dT;y<r[1]+r[3];y+=11)for(x=r[0];x<r[0]+r[2];x+=11){g.fillStyle=pick(['#d8a688','#cf9a7d','#e1b499','#c99278','#dcae92']);g.fillRect(x,y,10,10)}
 g.fillStyle='#8f9aa8';g.fillRect(r[0],dT-6,r[2],6);
 for(i=0;i<6;i++){var sl=r[2]/6,ww=64,wh=100;x=r[0]+sl*i+sl/2-ww/2;y=r[1]+24;
  g.fillStyle='#f4f5f4';arch(g,x-7,y-7,ww+14,wh+14);g.fill();g.fillStyle=glassG(g,x,y,ww,wh);arch(g,x,y,ww,wh);g.fill();
  g.save();arch(g,x,y,ww,wh);g.clip();g.strokeStyle='rgba(240,244,248,.85)';g.lineWidth=2;for(k=x+8;k<x+ww;k+=10){g.beginPath();g.moveTo(k,y);g.lineTo(k,y+wh);g.stroke()}for(k=y+12;k<y+wh;k+=16){g.beginPath();g.moveTo(x,k);g.lineTo(x+ww,k);g.stroke()}g.restore();
  e.fillStyle='rgba(255,212,150,.85)';arch(e,x,y,ww,wh);e.fill();g.fillStyle='#e9ebec';g.fillRect(x-9,y+wh+6,ww+18,6)}
 // --- Cami harim katı: büyük kemerli pencere + geometrik (yıldız) şebeke + rozet
 r=RG.MOSU;nz(g,r[0],r[1],r[2],r[3],'#a9b6ca',9);stains(g,r[0],r[1],r[2],r[3],30,true);e.fillStyle='#3a4250';e.fillRect(r[0],r[1],r[2],r[3]);
 g.fillStyle='#98a3b2';g.fillRect(r[0],r[1]+r[3]-12,r[2],12);
 for(i=0;i<5;i++){var sl2=r[2]/5,w2=100,h2=176;x=r[0]+sl2*i+sl2/2-w2/2;y=r[1]+70;
  g.fillStyle='#f2f3f3';arch(g,x-9,y-9,w2+18,h2+18);g.fill();g.fillStyle='#39404a';arch(g,x,y,w2,h2);g.fill();
  e.fillStyle='rgba(255,205,140,.95)';arch(e,x,y,w2,h2);e.fill();
  g.save();arch(g,x,y,w2,h2);g.clip();starLattice(g,x,y,w2,h2,17,'#e7eaee',3.2);g.restore();
  e.save();arch(e,x,y,w2,h2);e.clip();starLattice(e,x,y,w2,h2,17,'#000',3.2);e.restore();
  g.fillStyle='#f2f3f3';g.beginPath();g.arc(x+w2/2,r[1]+34,21,0,7);g.fill();g.fillStyle='#3b434d';g.beginPath();g.arc(x+w2/2,r[1]+34,15,0,7);g.fill();
  g.strokeStyle='#e7eaee';g.lineWidth=2;for(k=0;k<8;k++){g.beginPath();g.moveTo(x+w2/2,r[1]+34);g.lineTo(x+w2/2+Math.cos(k*.785)*15,r[1]+34+Math.sin(k*.785)*15);g.stroke()}
  e.fillStyle='rgba(255,205,140,.8)';e.beginPath();e.arc(x+w2/2,r[1]+34,15,0,7);e.fill()}
 // --- Kubbe kasnağı
 r=RG.MOSD;nz(g,r[0],r[1],r[2],r[3],'#b0bccd',8);e.fillStyle='#262c34';e.fillRect(r[0],r[1],r[2],r[3]);
 for(i=0;i<12;i++){x=r[0]+i*r[2]/12+r[2]/24-17;y=r[1]+18;g.fillStyle='#f4f5f5';arch(g,x-5,y-5,44,70);g.fill();g.fillStyle='#3a414a';arch(g,x,y,34,60);g.fill();
  g.save();arch(g,x,y,34,60);g.clip();starLattice(g,x,y,34,60,11,'#e5e8ec',2);g.restore();e.fillStyle='rgba(255,205,140,.9)';arch(e,x,y,34,60);e.fill()}
 // --- Eczane binası: gri sıva üst katlar + zeytin yeşili zemin kat
 r=RG.ECZU;nz(g,r[0],r[1],r[2],r[3],'#8d918c',14);stains(g,r[0],r[1],r[2],r[3],60,true);
 for(i=1;i<3;i++){g.fillStyle='#a2a6a1';g.fillRect(r[0],r[1]+i*128-8,r[2],7)}
 for(i=0;i<3;i++)[52,206,372].forEach(function(xx,j){pvcWin(g,e,r[0]+xx,r[1]+i*128+22,j===1?64:76,86)});
 r=RG.ECZS;nz(g,r[0],r[1],r[2],r[3],'#8d918c',14);stains(g,r[0],r[1],r[2],r[3],60,true);
 for(i=0;i<4;i++){g.fillStyle='#a2a6a1';g.fillRect(r[0],r[1]+i*92+88,r[2],6);if(i<3)[110,330].forEach(function(xx){pvcWin(g,e,r[0]+xx,r[1]+i*92+14,64,64)})}
 g.fillStyle='#6a7150';g.fillRect(r[0],r[1]+r[3]-88,r[2],88);
 r=RG.ECZG;nz(g,r[0],r[1],r[2],r[3],'#6c7452',10);g.fillStyle='#5b6244';for(x=r[0];x<r[0]+r[2];x+=64)g.fillRect(x,r[1],3,r[3]);
 g.fillStyle='#4d5340';g.fillRect(r[0],r[1],r[2],16);
 g.fillStyle='#d9dcd8';g.fillRect(r[0]+26,r[1]+24,270,100);var gg=g.createLinearGradient(0,r[1]+28,0,r[1]+124);gg.addColorStop(0,'#9fb0bd');gg.addColorStop(1,'#2d343a');g.fillStyle=gg;g.fillRect(r[0]+30,r[1]+28,262,96);
 for(k=0;k<3;k++)for(x=r[0]+40;x<r[0]+282;x+=7){g.fillStyle=pick(['#e8e8e8','#d33','#3a7','#36c','#eee','#fc3']);g.fillRect(x,r[1]+52+k*24,5,8)}
 g.fillStyle='#d9dcd8';g.fillRect(r[0]+320,r[1]+20,100,108);g.fillStyle=glassG(g,r[0]+326,r[1]+26,88,102);g.fillRect(r[0]+326,r[1]+26,88,102);g.fillStyle='#ccc';g.fillRect(r[0]+368,r[1]+26,4,102);
 e.fillStyle='rgba(200,215,230,.8)';e.fillRect(r[0]+30,r[1]+28,262,96);e.fillRect(r[0]+326,r[1]+26,88,102);
 g.fillStyle='#e8e8e8';g.fillRect(r[0]+446,r[1]+30,44,30);txt(g,'NÖBETÇİ',r[0]+468,r[1]+45,9,'#c22');
 // --- Market: somon/beyaz, üst katta kemerli pencereler + beyaz plastırlar, zemin dükkân
 r=RG.MKT;nz(g,r[0],r[1],r[2],r[3],'#e7a993',10);stains(g,r[0],r[1],r[2],90,25,true);
 g.fillStyle='#f6f3ee';g.fillRect(r[0],r[1],r[2],9);g.fillRect(r[0],r[1]+84,r[2],9);
 for(i=0;i<=8;i++){g.fillStyle='#f6f3ee';g.fillRect(r[0]+i*r[2]/8-7,r[1],14,90)}
 for(i=0;i<8;i++){x=r[0]+i*r[2]/8+18;y=r[1]+22;g.fillStyle='#fbfaf7';arch(g,x-4,y-4,36,56);g.fill();g.fillStyle=glassG(g,x,y,28,48);arch(g,x,y,28,48);g.fill();g.fillStyle='#fbfaf7';g.fillRect(x+12,y,3,48);if(rnd()<.4){e.fillStyle='#ffcf86';arch(e,x,y,28,48);e.fill()}}
 nz(g,r[0],r[1]+93,r[2],99,'#efebe4',8);
 [[10,120],[140,120],[270,110],[390,112]].forEach(function(o,j){var ox=r[0]+o[0],oy=r[1]+104,ow=o[1],oh=86;g.fillStyle='#7d8288';g.fillRect(ox-3,oy-8,ow+6,9);
  var gr=g.createLinearGradient(0,oy,0,oy+oh);gr.addColorStop(0,'#3e3a36');gr.addColorStop(1,'#1d1c1a');g.fillStyle=gr;g.fillRect(ox,oy,ow,oh);
  for(k=0;k<4;k++)for(x=ox+4;x<ox+ow-4;x+=6){g.fillStyle=pick(['#e8902c','#d43a2a','#6bab3a','#f2d34a','#3f8a3a','#c2662a','#ddd']);g.fillRect(x,oy+30+k*13,5,6)}
  e.fillStyle='rgba(240,205,150,.75)';e.fillRect(ox,oy,ow,oh)});
 r=RG.MKTS;nz(g,r[0],r[1],r[2],r[3],'#e5a690',10);stains(g,r[0],r[1],r[2],r[3],16,true);g.fillStyle='#f6f3ee';g.fillRect(r[0],r[1],r[2],7);g.fillRect(r[0],r[1],10,r[3]);g.fillRect(r[0]+r[2]-10,r[1],10,r[3]);g.fillRect(r[0],r[1]+70,r[2],6);
 pvcWin(g,e,r[0]+60,r[1]+20,40,38);pvcWin(g,e,r[0]+160,r[1]+20,40,38);g.fillStyle='#d8d0c4';g.fillRect(r[0],r[1]+r[3]-14,r[2],14);
 // --- Çay ocağı (kahvehane)
 r=RG.KHV;nz(g,r[0],r[1],r[2],r[3],'#ebe5d8',9);stains(g,r[0],r[1],r[2],r[3],20,true);g.fillStyle='#9a8a78';g.fillRect(r[0],r[1]+r[3]-22,r[2],22);
 [[20,110],[150,110],[280,60],[360,130]].forEach(function(o,j){var ox=r[0]+o[0],oy=r[1]+16,ow=o[1],oh=j===2?r[3]-18:92;g.fillStyle='#e0ded8';g.fillRect(ox-4,oy-4,ow+8,oh+8);
  var gr=g.createLinearGradient(0,oy,0,oy+oh);gr.addColorStop(0,'#5a4a3c');gr.addColorStop(1,'#2a221c');g.fillStyle=gr;g.fillRect(ox,oy,ow,oh);
  if(j!==2){g.fillStyle='#ddd';g.fillRect(ox+ow/2-2,oy,3,oh)}e.fillStyle='rgba(235,180,110,.75)';e.fillRect(ox,oy,ow,oh)});
 // --- Cumba (turuncu ahşap kapalı balkon)
 r=RG.CUMBA;g.fillStyle='#dc8432';g.fillRect(r[0],r[1],r[2],r[3]);for(y=r[1]+88;y<r[1]+r[3];y+=7){g.fillStyle='rgba(0,0,0,.18)';g.fillRect(r[0],y,r[2],2)}
 g.fillStyle='#b8621f';g.fillRect(r[0],r[1],r[2],6);g.fillRect(r[0],r[1]+84,r[2],5);
 for(i=0;i<6;i++){x=r[0]+6+i*41;g.fillStyle='#c06a22';g.fillRect(x-2,r[1]+10,36,74);g.fillStyle=glassG(g,x+2,r[1]+14,28,66);g.fillRect(x+2,r[1]+14,28,66);g.fillStyle='rgba(220,230,236,.35)';g.fillRect(x+2,r[1]+14,10,66);if(rnd()<.4){e.fillStyle='#ffc070';e.fillRect(x+2,r[1]+14,28,66)}}
 // --- Kiremit
 r=RG.TILE;for(y=r[1];y<r[1]+r[3];y+=16){for(x=r[0]-((y/16)%2)*10;x<r[0]+r[2];x+=20){var tc=pick(['#8c4431','#97503a','#7f3c2b','#a0563d']);var gr2=g.createLinearGradient(0,y,0,y+16);gr2.addColorStop(0,tc);gr2.addColorStop(1,'#4c2318');g.fillStyle=gr2;g.fillRect(x,y,19,16)}}
 // --- Çatı penceresi (market çatı kalkanı)
 r=RG.DORM;nz(g,r[0],r[1],r[2],r[3],'#efe9e2',8);pvcWin(g,e,r[0]+22,r[1]+26,34,50);pvcWin(g,e,r[0]+72,r[1]+26,34,50);
 // --- Parke taşı (kaldırım)
 r=RG.PAV;nz(g,r[0],r[1],r[2],r[3],'#a9a49a',22);g.fillStyle='rgba(0,0,0,.18)';for(y=r[1];y<r[1]+r[3];y+=16){g.fillRect(r[0],y,r[2],2);for(x=r[0]+((y/16)%2)*12;x<r[0]+r[2];x+=24)g.fillRect(x,y,2,16)}
 // --- Tente: kırmızı-beyaz çizgi
 r=RG.AWN;for(x=r[0];x<r[0]+r[2];x+=32){g.fillStyle='#c4272d';g.fillRect(x,r[1],16,r[3]);g.fillStyle='#f2efe8';g.fillRect(x+16,r[1],16,r[3])}stains(g,r[0],r[1],r[2],r[3],12,true);
 // --- Tabelalar (gece ışıklı)
 function sign(rr,bg,fg,t1,s1,t2,s2,glow){[g,e].forEach(function(G,m){if(m&&!glow)return;G.fillStyle=bg;G.fillRect(rr[0],rr[1],rr[2],rr[3]);if(t2){txt(G,t1,rr[0]+rr[2]/2,rr[1]+rr[3]*.4,s1,fg);txt(G,t2,rr[0]+rr[2]/2,rr[1]+rr[3]*.82,s2,fg,'600')}else txt(G,t1,rr[0]+rr[2]/2,rr[1]+rr[3]/2+1,s1,fg)})}
 sign(RG.S_ECZ,'#d6242c','#fff','ECZANE',40,'AKASYA',12,1);
 sign(RG.S_MKT,'#f8f7f4','#d3202a','AKASYA MARKET',28,0,0,1);g.fillStyle='#d3202a';g.fillRect(RG.S_MKT[0],RG.S_MKT[1]+58,256,6);
 sign(RG.S_CAY,'#b4181c','#fff','ÇAY OCAĞI',36,0,0,1);
 sign(RG.S_E,'#d6242c','#fff','E',50,0,0,1);
 r=RG.ONEW;g.fillStyle='#fff';g.fillRect(r[0],r[1],64,64);g.fillStyle='#1556a8';g.fillRect(r[0]+3,r[1]+3,58,58);g.fillStyle='#fff';g.beginPath();g.moveTo(r[0]+32,r[1]+8);g.lineTo(r[0]+50,r[1]+28);g.lineTo(r[0]+38,r[1]+28);g.lineTo(r[0]+38,r[1]+56);g.lineTo(r[0]+26,r[1]+56);g.lineTo(r[0]+26,r[1]+28);g.lineTo(r[0]+14,r[1]+28);g.closePath();g.fill();
 e.fillStyle='#1a3060';e.fillRect(r[0],r[1],64,64);
 r=RG.IST;g.fillStyle='#fff';g.fillRect(r[0],r[1],r[2],r[3]);g.strokeStyle='#111';g.lineWidth=3;g.strokeRect(r[0]+2,r[1]+2,r[2]-4,r[3]-4);txt(g,'◄ İstanbul',r[0]+r[2]/2,r[1]+21,19,'#111');
 r=RG.MELON;g.fillStyle='#2c5a28';g.fillRect(r[0],r[1],64,64);for(x=r[0];x<r[0]+64;x+=8){g.fillStyle='#86b35c';for(y=r[1];y<r[1]+64;y+=2)g.fillRect(x+Math.sin(y*.3)*1.5,y,3,2)}
 r=RG.CRATE;g.fillStyle='#2a4ea0';g.fillRect(r[0],r[1],64,64);g.fillStyle='#14306e';for(y=r[1]+8;y<r[1]+56;y+=12)for(x=r[0]+4;x<r[0]+60;x+=10)g.fillRect(x,y,7,7);g.fillStyle='#3a62b8';g.fillRect(r[0],r[1],64,5);
 [['WHITE','#ffffff','#ffffff'],['WDIM','#f3f3f0','#55554f'],['GRAYP','#b6bbc1','#000'],['WOOD','#6a4a30','#000']].forEach(function(q){var rr=RG[q[0]];g.fillStyle=q[1];g.fillRect(rr[0]-4,rr[1]-4,rr[2]+8,rr[3]+8);e.fillStyle=q[2];e.fillRect(rr[0]-4,rr[1]-4,rr[2]+8,rr[3]+8)});
 var e2=cv(512,256),e3=e2.getContext('2d');e3.drawImage(ec,0,0,512,256);e3.globalCompositeOperation='multiply';e3.fillStyle='#8a8a8a';e3.fillRect(0,0,512,256);
 // alfa atlası: korkuluklar, şebekeler, tente saçağı
 var xc=cv(XW,XH),x2=xc.getContext('2d');x2.clearRect(0,0,XW,XH);
 r=XR.RAIL;x2.fillStyle='#3d2c22';x2.fillRect(r[0],r[1]+2,r[2],6);x2.fillRect(r[0],r[1]+r[3]-7,r[2],5);for(x=r[0]+2;x<r[0]+r[2];x+=9)x2.fillRect(x,r[1]+2,3,r[3]-4);for(x=r[0];x<r[0]+r[2];x+=64)x2.fillRect(x,r[1],6,r[3]);
 r=XR.BALU;x2.fillStyle='#f1f1ee';x2.fillRect(r[0],r[1],r[2],9);x2.fillRect(r[0],r[1]+r[3]-8,r[2],8);
 for(x=r[0]+8;x<r[0]+r[2];x+=16){x2.beginPath();x2.moveTo(x-3,r[1]+9);x2.quadraticCurveTo(x-8,r[1]+38,x-3,r[1]+56);x2.lineTo(x+3,r[1]+56);x2.quadraticCurveTo(x+8,r[1]+38,x+3,r[1]+9);x2.closePath();x2.fill()}
 r=XR.LATT;x2.fillStyle='#f1f1ee';x2.fillRect(r[0],r[1],r[2],7);x2.fillRect(r[0],r[1]+r[3]-7,r[2],7);x2.strokeStyle='#f1f1ee';x2.lineWidth=4;for(x=r[0];x<r[0]+r[2];x+=24){x2.beginPath();x2.moveTo(x,r[1]+7);x2.lineTo(x+24,r[1]+r[3]-7);x2.moveTo(x+24,r[1]+7);x2.lineTo(x,r[1]+r[3]-7);x2.stroke();x2.fillRect(x-2,r[1],4,r[3])}
 r=XR.SCAL;for(x=r[0];x<r[0]+r[2];x+=32){[[0,'#c4272d'],[16,'#f2efe8']].forEach(function(s){x2.fillStyle=s[1];x2.fillRect(x+s[0],r[1],16,18);x2.beginPath();x2.arc(x+s[0]+8,r[1]+18,8,0,Math.PI);x2.fill()})}
 r=XR.WIRE;x2.fillStyle='#2e3a2e';for(x=r[0];x<r[0]+r[2];x+=8){x2.fillRect(x,r[1],2,r[3])}x2.fillRect(r[0],r[1],r[2],3);
 function T3(c,srgb){var t=new THREE.CanvasTexture(c);if(srgb)t.encoding=THREE.sRGBEncoding;t.anisotropy=4;return t}
 ATL={map:T3(c,1),emi:T3(e2,1),x:T3(xc,1)};return ATL}

// ================= 3) GEOMETRİ KİTİ =================
function Kit(){this.p=[];this.n=[];this.u=[];this.c=[]}
function cr(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
function sb(a,b){return [a[0]-b[0],a[1]-b[1],a[2]-b[2]]}
function nr(a){var l=Math.hypot(a[0],a[1],a[2])||1;return [a[0]/l,a[1]/l,a[2]/l]}
function dt(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]}
Kit.prototype.v=function(P,N,U,C){this.p.push(P[0],P[1],P[2]);this.n.push(N[0],N[1],N[2]);this.u.push(U[0],U[1]);this.c.push(C[0],C[1],C[2])};
// a=sol-alt b=sağ-alt c=sağ-üst d=sol-üst (dışarıdan bakınca). out verilirse yön/ayna düzeltilir. R=[u0,v0,u1,v1]
Kit.prototype.quad=function(a,b,c,d,R,col,out,NN){var n=nr(cr(sb(c,a),sb(d,b)));
 if(out&&dt(n,out)<0){var t=a;a=b;b=t;t=c;c=d;d=t;n=[-n[0],-n[1],-n[2]];if(NN)NN=[NN[1],NN[0],NN[3],NN[2]]}
 var N=NN||[n,n,n,n],ua=[R[0],R[1]],ub=[R[2],R[1]],uc=[R[2],R[3]],ud=[R[0],R[3]];
 this.v(a,N[0],ua,col);this.v(b,N[1],ub,col);this.v(c,N[2],uc,col);this.v(a,N[0],ua,col);this.v(c,N[2],uc,col);this.v(d,N[3],ud,col)};
Kit.prototype.tri=function(a,b,c,R,col,out){var n=nr(cr(sb(b,a),sb(c,a)));if(out&&dt(n,out)<0){var t=b;b=c;c=t;n=[-n[0],-n[1],-n[2]]}
 var u=[(R[0]+R[2])/2,(R[1]+R[3])/2];this.v(a,n,[R[0],R[1]],col);this.v(b,n,[R[2],R[1]],col);this.v(c,n,u,col)};
Kit.prototype.mesh=function(mat,cast,recv){if(!this.p.length)return null;var g=new THREE.BufferGeometry();
 g.setAttribute('position',new THREE.Float32BufferAttribute(this.p,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(this.n,3));
 g.setAttribute('uv',new THREE.Float32BufferAttribute(this.u,2));g.setAttribute('color',new THREE.Float32BufferAttribute(this.c,3));g.computeBoundingSphere();
 var m=new THREE.Mesh(g,mat);m.castShadow=!!cast;m.receiveShadow=!!recv;return m};
var _col=null;function C(hex,k){if(!_col)_col=new THREE.Color();_col.setHex(hex);_col.convertSRGBToLinear();k=k||1;return [_col.r*k,_col.g*k,_col.b*k]}
var ONE=[1,1,1],UP=[0,1,0],DN=[0,-1,0],U0=[0,0,1,1];
// çerçeve: o merkez, u ve w yatay eksenler, s ölçek
function Fr(o,u,w,s){return {o:o,u:u,w:w,s:s||1}}
function FP(F,u,y,w){var s=F.s;return [F.o[0]+(F.u[0]*u+F.w[0]*w)*s,y*s,F.o[1]+(F.u[1]*u+F.w[1]*w)*s]}
function FD(F,u,y,w){return [F.u[0]*u+F.w[0]*w,y,F.u[1]*u+F.w[1]*w]}
function frAng(x,z,ang,s){var c=Math.cos(ang),n=Math.sin(ang);return Fr([x,z],[c,n],[-n,c],s)}
// kutu: f={pu,nu,pw,nw,t,b} uv dikdörtgenleri (yoksa o yüz çizilmez); f.all hepsi
function box(K,F,u0,u1,y0,y1,w0,w1,f,col){col=col||ONE;var A=f.all;
 var P=function(u,y,w){return FP(F,u,y,w)};
 if(f.pu||A)K.quad(P(u1,y0,w1),P(u1,y0,w0),P(u1,y1,w0),P(u1,y1,w1),f.pu||A,col,FD(F,1,0,0));
 if(f.nu||A)K.quad(P(u0,y0,w0),P(u0,y0,w1),P(u0,y1,w1),P(u0,y1,w0),f.nu||A,col,FD(F,-1,0,0));
 if(f.pw||A)K.quad(P(u0,y0,w1),P(u1,y0,w1),P(u1,y1,w1),P(u0,y1,w1),f.pw||A,col,FD(F,0,0,1));
 if(f.nw||A)K.quad(P(u1,y0,w0),P(u0,y0,w0),P(u0,y1,w0),P(u1,y1,w0),f.nw||A,col,FD(F,0,0,-1));
 if(f.t||A)K.quad(P(u0,y1,w0),P(u1,y1,w0),P(u1,y1,w1),P(u0,y1,w1),f.t||A,col,UP);
 if(f.b)K.quad(P(u0,y0,w1),P(u1,y0,w1),P(u1,y0,w0),P(u0,y0,w0),f.b,col,DN)}
// silindir / koni (dünya koordinatı merkez), R yatayda sarılır
function cyl(K,x,z,y0,y1,r0,r1,seg,R,col,o){o=o||{};col=col||ONE;var h=y1-y0,a0=o.a0||0,ca=o.alt;
 for(var i=0;i<seg;i++){var t0=a0+i/seg*Math.PI*2,t1=a0+(i+1)/seg*Math.PI*2,c0=Math.cos(t0),s0=Math.sin(t0),c1=Math.cos(t1),s1=Math.sin(t1);
  var ur=[R[0]+(R[2]-R[0])*i/seg,R[1],R[0]+(R[2]-R[0])*(i+1)/seg,R[3]],sl=(r0-r1)/(h||1);
  var n0=o.flat?null:[nr([c0,sl,s0]),nr([c1,sl,s1]),nr([c1,sl,s1]),nr([c0,sl,s0])];
  var cc=ca&&i%2?[col[0]*ca,col[1]*ca,col[2]*ca]:col,tm=(t0+t1)/2;
  K.quad([x+c0*r0,y0,z+s0*r0],[x+c1*r0,y0,z+s1*r0],[x+c1*r1,y1,z+s1*r1],[x+c0*r1,y1,z+s0*r1],ur,cc,[Math.cos(tm),0,Math.sin(tm)],n0);
  if(o.cap1&&r1>0)K.tri([x,y1,z],[x+c0*r1,y1,z+s0*r1],[x+c1*r1,y1,z+s1*r1],o.capR||R,col,UP);
  if(o.cap0&&r0>0)K.tri([x,y0,z],[x+c1*r0,y0,z+s1*r0],[x+c0*r0,y0,z+s0*r0],o.capR||R,col,DN)}}
// kubbe (yarım elipsoid)
function dome(K,x,y0,z,r,hr,seg,rings,R,col,alt){col=col||ONE;
 for(var j=0;j<rings;j++){var p0=j/rings*Math.PI/2,p1=(j+1)/rings*Math.PI/2;
  for(var i=0;i<seg;i++){var t0=i/seg*Math.PI*2,t1=(i+1)/seg*Math.PI*2;
   var V=function(t,p){return [x+Math.cos(t)*Math.cos(p)*r,y0+Math.sin(p)*hr,z+Math.sin(t)*Math.cos(p)*r]},N=function(t,p){return nr([Math.cos(t)*Math.cos(p)/r,Math.sin(p)/hr,Math.sin(t)*Math.cos(p)/r])};
   var cc=alt&&i%2?[col[0]*alt,col[1]*alt,col[2]*alt]:col,ur=[R[0]+(R[2]-R[0])*i/seg,R[1]+(R[3]-R[1])*j/rings,R[0]+(R[2]-R[0])*(i+1)/seg,R[1]+(R[3]-R[1])*(j+1)/rings];
   K.quad(V(t0,p0),V(t1,p0),V(t1,p1),V(t0,p1),ur,cc,N((t0+t1)/2,(p0+p1)/2),[N(t0,p0),N(t1,p0),N(t1,p1),N(t0,p1)])}}}
function sphere(K,x,y,z,r,seg,R,col){dome(K,x,y,z,r,r,seg,Math.max(2,seg/3|0),R,col);
 for(var j=0;j<Math.max(2,seg/3|0);j++){var rings=Math.max(2,seg/3|0),p0=-j/rings*Math.PI/2,p1=-(j+1)/rings*Math.PI/2;
  for(var i=0;i<seg;i++){var t0=i/seg*Math.PI*2,t1=(i+1)/seg*Math.PI*2,V=function(t,p){return [x+Math.cos(t)*Math.cos(p)*r,y+Math.sin(p)*r,z+Math.sin(t)*Math.cos(p)*r]};
   var n0=nr(sb(V((t0+t1)/2,(p0+p1)/2),[x,y,z]));K.quad(V(t1,p0),V(t0,p0),V(t0,p1),V(t1,p1),R,col,n0)}}}
// kırma çatı
function hip(K,F,u0,u1,w0,w1,y,rise,R,col,soffit){col=col||ONE;var cu=(u0+u1)/2,cw=(w0+w1)/2,hu=(u1-u0)/2,hw=(w1-w0)/2,P=function(u,yy,w){return FP(F,u,yy,w)};
 var c0=P(u0,y,w0),c1=P(u1,y,w0),c2=P(u1,y,w1),c3=P(u0,y,w1),r0,r1,Y=y+rise;
 if(hu>=hw){r0=P(cu-(hu-hw),Y,cw);r1=P(cu+(hu-hw),Y,cw);K.quad(c1,c0,r0,r1,R,col,FD(F,0,1,-1));K.quad(c3,c2,r1,r0,R,col,FD(F,0,1,1));K.tri(c0,c3,r0,R,col,FD(F,-1,1,0));K.tri(c2,c1,r1,R,col,FD(F,1,1,0))}
 else{r0=P(cu,Y,cw-(hw-hu));r1=P(cu,Y,cw+(hw-hu));K.quad(c2,c1,r0,r1,R,col,FD(F,1,1,0));K.quad(c0,c3,r1,r0,R,col,FD(F,-1,1,0));K.tri(c1,c0,r0,R,col,FD(F,0,1,-1));K.tri(c3,c2,r1,R,col,FD(F,0,1,1))}
 if(soffit)K.quad(c3,c2,c1,c0,soffit,col,DN)}
// dikey düzlem (iki yüzlü malzemeler için): P0->P1 alt kenar
function vplane(K,P0,P1,y0,y1,R,col,out){K.quad([P0[0],y0,P0[1]],[P1[0],y0,P1[1]],[P1[0],y1,P1[1]],[P0[0],y1,P0[1]],R,col||ONE,out)}

// ================= 4) CAMİ =================
function mosque(KS,F,o){o=o||{};var A=KS.A,P=KS.P,M=KS.M,X=KS.X,s=F.s,u=atlas()&&0;
 var WC=C(0xb7c2d2),BG=C(0x8796aa),WH=C(0xf3f3f0),NV=C(0x1d2c6c),LD=C(0x6f787f),GD=C(0xd8ac3c),WHL=C(0xffffff);
 var G=uvR(RG.MOSG),UU=uvR(RG.MOSU),D=uvR(RG.MOSD),GP=uvR(RG.GRAYP),WD=uvR(RG.WDIM),WT=uvR(RG.WHITE),BA=uvR(XR.BALU,1,1),LA=uvR(XR.LATT,1,1);
 var Q=function(u,w){return FP(F,u,0,w)};
 box(A,F,-11,11,0,4.6,-11,11,{pu:G,nu:G,pw:G,nw:G,t:GP});
 box(P,F,-11.35,11.35,4.6,5.0,-11.35,11.35,{all:U0,b:U0},BG);
 // teras korkuluğu (beyaz babalar)
 [[-11.1,-11.1,11.1,-11.1],[11.1,-11.1,11.1,11.1],[11.1,11.1,-11.1,11.1],[-11.1,11.1,-11.1,-11.1]].forEach(function(e){var p0=Q(e[0],e[1]),p1=Q(e[2],e[3]),L=Math.hypot(p1[0]-p0[0],p1[2]-p0[2]),n=Math.max(1,Math.round(L/(4*s)));
  for(var i=0;i<n;i++){var a=[p0[0]+(p1[0]-p0[0])*i/n,p0[2]+(p1[2]-p0[2])*i/n],b=[p0[0]+(p1[0]-p0[0])*(i+1)/n,p0[2]+(p1[2]-p0[2])*(i+1)/n];vplane(X,a,b,5.0*s,6.0*s,BA)}});
 // harim
 box(A,F,-10,10,5.0,11.5,-8,10.5,{pu:UU,nu:UU,pw:UU,nw:UU});
 box(P,F,-10.35,10.35,11.5,11.95,-8.35,10.85,{all:U0,b:U0},BG);
 // son cemaat yeri: sütunlar + saçak + 3 küçük kubbe
 [-9.4,-6.2,-3.1,0,3.1,6.2,9.4].forEach(function(uu){var q=Q(uu,-10.5);cyl(P,q[0],q[2],5*s,8.7*s,.26*s,.22*s,8,U0,WH);cyl(P,q[0],q[2],8.55*s,8.85*s,.36*s,.36*s,8,U0,WH,{cap0:1})});
 box(P,F,-10.6,10.6,8.85,9.45,-11.0,-8,{all:U0,b:U0},WH);box(P,F,-10.7,10.7,9.45,9.6,-11.1,-7.9,{all:U0,b:U0},BG);
 [-6.2,0,6.2].forEach(function(uu){var q=Q(uu,-9.5);cyl(P,q[0],q[2],9.6*s,9.95*s,1.25*s,1.25*s,12,U0,WH);dome(P,q[0],9.95*s,q[2],1.3*s,1.05*s,12,4,U0,LD,.9);cyl(M,q[0],q[2],11*s,11.5*s,.05*s,.05*s,5,U0,GD)});
 // kubbe: sekizgen kaide + kasnak + kubbe + alem
 var c=Q(0,1.25),cx=c[0],cz=c[2];
 cyl(P,cx,cz,11.95*s,12.7*s,7.1*s,6.8*s,8,U0,BG,{cap1:1,a0:Math.PI/8});
 cyl(A,cx,cz,12.7*s,14.7*s,6.1*s,6.1*s,16,D);
 cyl(P,cx,cz,14.7*s,15.0*s,6.5*s,6.5*s,16,U0,BG,{cap0:1,cap1:1});
 dome(P,cx,15.0*s,cz,6.35*s,5.7*s,24,8,U0,LD,.9);
 cyl(M,cx,cz,20.6*s,21.3*s,.14*s,.1*s,6,U0,GD);sphere(M,cx,21.45*s,cz,.22*s,6,U0,GD);
 // hilal
 var fx=FD(F,1,0,0);for(var k=0;k<7;k++){var an=-1.1+k*2.2/6,yy=22.15*s+Math.sin(an)*.42*s,hh=Math.cos(an)*.42*s,q0=[cx+fx[0]*hh,cz+fx[2]*hh];box(M,frAng(q0[0],q0[1],Math.atan2(fx[2],fx[0]),1),-.04*s,.04*s,yy/1-.07*s,yy+.07*s,-.03*s,.03*s,{all:U0},GD)}
 cyl(M,cx,cz,21.6*s,21.75*s,.04*s,.04*s,4,U0,GD);
 // köşe ağırlık kuleleri
 [[-8.9,-6.8],[8.9,-6.8],[-8.9,9.3],[8.9,9.3]].forEach(function(p){var q=Q(p[0],p[1]);cyl(P,q[0],q[2],11.95*s,13.5*s,.8*s,.8*s,8,U0,WC,{a0:Math.PI/8});cyl(P,q[0],q[2],13.5*s,13.7*s,.95*s,.95*s,8,U0,BG,{cap0:1,a0:Math.PI/8});dome(P,q[0],13.7*s,q[2],.85*s,.95*s,8,3,U0,LD);cyl(M,q[0],q[2],14.6*s,15.1*s,.04*s,.03*s,4,U0,GD)});
 // MİNARE
 var mp=Q(o.mu===undefined?12.7:o.mu,o.mw===undefined?-6:o.mw),mx=mp[0],mz=mp[2],FMn=Fr([mx,mz],F.u,F.w,s);
 box(P,FMn,-1.3,1.3,0,11.6,-1.3,1.3,{pu:U0,nu:U0,pw:U0,nw:U0,t:U0},C(0xa2afc2));
 box(P,FMn,-1.5,1.5,11.6,12.05,-1.5,1.5,{all:U0,b:U0},BG);
 var a8=Math.atan2(F.u[1],F.u[0])+Math.PI/8;
 cyl(M,mx,mz,12.05*s,14.6*s,1.6*s,1.12*s,8,U0,NV,{a0:a8,flat:1});
 cyl(A,mx,mz,14.6*s,27.4*s,1.12*s,1.06*s,12,WD,WHL,{alt:.9});
 cyl(M,mx,mz,27.4*s,28.4*s,1.15*s,1.15*s,12,U0,NV);
 cyl(P,mx,mz,28.4*s,28.75*s,1.2*s,1.2*s,12,U0,WH,{cap0:1});
 cyl(P,mx,mz,28.75*s,29.4*s,1.15*s,1.9*s,12,U0,WH);
 cyl(A,mx,mz,29.25*s,29.4*s,1.92*s,1.92*s,12,WT,WHL);
 cyl(M,mx,mz,29.4*s,29.62*s,1.95*s,1.95*s,12,U0,NV,{cap1:1,cap0:1});
 cyl(X,mx,mz,29.62*s,30.6*s,1.9*s,1.9*s,12,LA);
 cyl(A,mx,mz,29.62*s,35.5*s,.98*s,.95*s,12,WD,WHL,{alt:.9});
 cyl(M,mx,mz,34.5*s,34.95*s,.99*s,.99*s,12,U0,NV);
 cyl(P,mx,mz,35.5*s,35.85*s,1.2*s,1.2*s,12,U0,WH,{cap0:1,cap1:1});
 cyl(M,mx,mz,35.85*s,42.6*s,1.1*s,.02*s,12,U0,NV);
 cyl(M,mx,mz,42.5*s,43.6*s,.06*s,.05*s,5,U0,GD);sphere(M,mx,42.95*s,mz,.17*s,6,U0,GD);sphere(M,mx,43.35*s,mz,.12*s,6,U0,GD);
 for(k=0;k<6;k++){var an2=-1.1+k*2.2/5,y2=43.95*s+Math.sin(an2)*.3*s,h2=Math.cos(an2)*.3*s;box(M,frAng(mx+fx[0]*h2,mz+fx[2]*h2,Math.atan2(fx[2],fx[0]),1),-.03*s,.03*s,y2-.05*s,y2+.05*s,-.02*s,.02*s,{all:U0},GD)}
 return {mx:mx,mz:mz}}

// ================= 5) YARDIMCI DONATILAR =================
function chair(P,x,z,ang,col){var F=frAng(x,z,ang,1),U=U0;box(P,F,-.21,.21,.42,.46,-.21,.21,{all:U},col);box(P,F,-.21,.21,.46,.92,.17,.21,{all:U},col);
 [[-.18,-.18],[.18,-.18],[-.18,.18],[.18,.18]].forEach(function(q){box(P,F,q[0]-.025,q[0]+.025,0,.42,q[1]-.025,q[1]+.025,{pu:U,nu:U,pw:U,nw:U},col)})}
function table(P,x,z,ang){var F=frAng(x,z,ang,1);box(P,F,-.4,.4,.7,.74,-.4,.4,{all:U0,b:U0},C(0xe9e4d6));box(P,F,-.04,.04,0,.7,-.04,.04,{pu:U0,nu:U0,pw:U0,nw:U0},C(0x5a5a5a))}
function cone(P,x,z){cyl(P,x,z,0.02,.72,.17,.03,8,U0,C(0xf06a1c),{cap1:1});cyl(P,x,z,.36,.48,.115,.095,8,U0,C(0xf4f4f4));box(P,frAng(x,z,.3,1),-.21,.21,0,.04,-.21,.21,{all:U0},C(0x222222))}
function pole(M,x,z,h,r,col){cyl(M,x,z,0,h,r,r*.85,6,U0,col||C(0x8a8e92),{cap1:1})}

// ================= 6) ANA KURULUM =================
var built=false,STAT={tris:0,calls:0,items:[]};
function mats(NIGHT){var t=atlas();
 var A=new THREE.MeshStandardMaterial({map:t.map,emissive:0xffffff,emissiveMap:t.emi,emissiveIntensity:.05,vertexColors:true,roughness:.85,envMapIntensity:.35});
 var P=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.72,envMapIntensity:.4});
 var M=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.38,metalness:.6,envMapIntensity:.9});
 var X=new THREE.MeshStandardMaterial({map:t.x,alphaTest:.5,side:THREE.DoubleSide,vertexColors:true,roughness:.6,envMapIntensity:.4});
 return {A:A,P:P,M:M,X:X}}
var MT=null;
function useMats(NIGHT){if(!MT)MT=mats();if(NIGHT&&NIGHT.bldMats&&NIGHT.bldMats.indexOf(MT.A)<0)NIGHT.bldMats.push(MT.A);return MT}
function roadDist(x,z){var b=1e9;if(typeof OSMD!=='undefined')OSMD.roads.forEach(function(r){b=Math.min(b,segD(x,z,r[1])-r[0]/2)});return b}
function kits(){return {A:new Kit(),P:new Kit(),M:new Kit(),X:new Kit()}}
function flush(KS,scene,lab){var o=[];[['A',1,1],['P',1,1],['M',1,0],['X',1,0]].forEach(function(q){var m=KS[q[0]].mesh(MT[q[0]],q[1],q[2]);if(m){scene.add(m);o.push(m);var t=m.geometry.attributes.position.count/3;STAT.calls++;STAT.tris+=t;STAT.items.push((lab||'?')+'.'+q[0]+':'+t)}});return o}

function build(ctx){if(built)return;built=true;var scene=ctx.scene,addOb=ctx.addOb||function(){};useMats(ctx.NIGHT);var KS=kits(),A=KS.A,P=KS.P,M=KS.M,X=KS.X;
 var F0=Fr(J,T,Lv,1),PV=uvR(RG.PAV),WD=uvR(RG.WOOD),GP=uvR(RG.GRAYP);
 function ob(a,l,r){var q=W(a,l);addOb(q[0],q[1],r)}
 // [AJAN:polish] katı landmark'lar: oyunda bina çarpışması yok (oyuncu pist koridoruna kelepçeli: |lat|<=HALF+SW-1.05), tek katı mekanizma addOb daireleri.
 // Duvar/bina çevresine daire zinciri dizilir; yalnız koridordan erişilebilen (pist eksenine <REACH m) daireler eklenir → OBK küçük kalır.
 // Cami parseli: pist, kavşağa gelmeden önce a≈-40 hattından (+l yönünden) gelip a≈-38'de Akasya'ya dönüyor; eski yerleşim (a=-46..-5.6) pistin ÜSTÜNDEYDİ
 // (avlu duvarı yolu kesiyor, cami gövdesi asfalta taşıyordu). Parsel artık pist kaldırımı (TE) ile yan sokak (a=-6.2) arasına sığdırılıyor.
 var TE=[],MA0=-27.8;
 if(ctx.pts&&ctx.lefts){var mc=W(-17,30),lastE=null;for(var tk=ctx.NS-200;tk<ctx.NS-15;tk++){var tp=ctx.pts[tk],tl=ctx.lefts[tk],tsg=((mc[0]-tp.x)*tl.x+(mc[1]-tp.z)*tl.z)>0?1:-1,to=ctx.HALF+ctx.SW+.5,
    te=AL(tp.x+tl.x*to*tsg,tp.z+tl.z*to*tsg);if(te[1]<12.2||te[1]>46||te[0]>-8)continue;if(lastE&&Math.hypot(te[0]-lastE[0],te[1]-lastE[1])<2.6)continue;TE.push(te);lastE=te}}
 var REACH=(ctx.HALF||7)+(ctx.SW||4.5)-.05,solidN=0,SOLID=[]; // araç dairesi en çok HALF+SW-1.05+.92+r = 11.37+r m'ye uzanır
 function solidLine(a0,l0,a1,l1,r){var L=Math.hypot(a1-a0,l1-l0),n=Math.max(1,Math.ceil(L/(r*1.5)));for(var i=0;i<=n;i++){var q=W(a0+(a1-a0)*i/n,l0+(l1-l0)*i/n);
   if(ctx.minRoadDist&&ctx.minRoadDist(q[0],q[1])>REACH+r)continue;addOb(q[0],q[1],r,'solid');solidN++}}
 function solidBox(a0,a1,l0,l1){var r=.8;solidLine(a0+r,l0+r,a1-r,l0+r,r);solidLine(a0+r,l1-r,a1-r,l1-r,r);solidLine(a0+r,l0+r,a0+r,l1-r,r);solidLine(a1-r,l0+r,a1-r,l1-r,r)}
 SOLID.push(function(){WSEG.forEach(function(e){solidLine(e[0],e[1],e[2],e[3],.35)}); // cami avlu duvarı
  solidBox(-16.9-9.9,-16.9+9.9,30.5-9.9,30.5+9.9);solidLine(-8.9,19.3,-8.9,19.3,1.5)}); // cami + minare
 solidBox(13.5,24.5,17.5,26); // çay ocağı
 solidBox(7.8,21.5,-25,-13.3);solidLine(13.8,-12.6,19.6,-12.6,.5); // eczane + cumba
 solidBox(-32.5,-12.5,-26,-14); // market
 // --- avlu / ön alan zeminleri (parke)
 [[MA0,-5.8,11.5,46],[5.8,30,11.5,34],[5.8,25,-28,-11.5],[-37,-5.8,-29,-11.5]].forEach(function(e){var n=Math.ceil((e[1]-e[0])/6),m=Math.ceil((e[3]-e[2])/6);
  for(var i=0;i<n;i++)for(var j=0;j<m;j++){var a0=e[0]+(e[1]-e[0])*i/n,a1=e[0]+(e[1]-e[0])*(i+1)/n,l0=e[2]+(e[3]-e[2])*j/m,l1=e[2]+(e[3]-e[2])*(j+1)/m;
   P.quad(FP(F0,a0,.16,l0),FP(F0,a1,.16,l0),FP(F0,a1,.16,l1),FP(F0,a0,.16,l1),U0,C(0xa7a399,.9+rnd()*.12),UP)}});
 // ---- CAMİ (Mithatpaşa İstasyon Camii)
 var FM=Fr(W(-16.9,30.5),T,Lv,.87);var mm=mosque(KS,FM,{mu:9.2,mw:-12.9}); // [AJAN:polish] eski: W(-23,30.5) ölçek 1, minare yanda (mu 12.7) — pist koridoruna taşıyordu
 // avlu duvarı + yeşil boru korkuluk
 var GR=C(0x3f8a48);
 var WSEG=[],wc=TE.length?TE[TE.length-1]:[-27,12.2]; // [AJAN:polish] duvar: pist kaldırımını izler → ön cephe → yan sokak
 for(var wi=1;wi<TE.length;wi++)WSEG.push([TE[wi-1][0],TE[wi-1][1],TE[wi][0],TE[wi][1]]);
 WSEG.push([wc[0],wc[1],-6.2,12.2],[-6.2,12.2,-6.2,46]);
 WSEG.forEach(function(e){var p0=W(e[0],e[1]),p1=W(e[2],e[3]),L=Math.hypot(p1[0]-p0[0],p1[1]-p0[1]),ang=Math.atan2(p1[1]-p0[1],p1[0]-p0[0]),Fm=frAng((p0[0]+p1[0])/2,(p0[1]+p1[1])/2,ang,1);
  box(P,Fm,-L/2,L/2,0,.55,-.15,.15,{all:U0},C(0xb9b6ae));
  [.95,1.3].forEach(function(y){var n=Math.ceil(L/3);for(var i=0;i<n;i++){var u0=-L/2+L*i/n,u1=-L/2+L*(i+1)/n;var Fi=Fm;var q0=FP(Fi,u0,0,0),q1=FP(Fi,u1,0,0);
   box(M,Fm,u0,u1,y-.03,y+.03,-.03,.03,{pu:U0,nu:U0,pw:U0,nw:U0,t:U0,b:U0},GR)}});
  for(var u=-L/2;u<=L/2+.01;u+=2.4){box(M,Fm,u-.035,u+.035,.55,1.36,-.035,.035,{pu:U0,nu:U0,pw:U0,nw:U0,t:U0},GR)}});
 // ---- ÇAY OCAĞI
 var FH=Fr(W(18.5,21),T,Lv,1),KH=uvR(RG.KHV),AWN=uvR(RG.AWN),SC=uvR(XR.SCAL,1,1);
 box(A,FH,-5,6,0,3.2,-3.5,5,{pu:KH,nu:KH,pw:KH,nw:KH});
 var RW=C(0xe6e6e1);
 (function(){var p=function(u,y,w){return FP(FH,u,y,w)};var y0=3.2,yr=4.15,wm=.75;
  P.quad(p(6.8,y0,-4.4),p(-5.8,y0,-4.4),p(-5.8,yr,wm),p(6.8,yr,wm),U0,RW,FD(FH,0,1,-1));P.quad(p(-5.8,y0,5.9),p(6.8,y0,5.9),p(6.8,yr,wm),p(-5.8,yr,wm),U0,RW,FD(FH,0,1,1));
  P.quad(p(-5.8,y0,-4.4),p(6.8,y0,-4.4),p(6.8,yr,wm),p(-5.8,yr,wm),U0,C(0x9a9a96),FD(FH,0,-1,1));P.quad(p(6.8,y0,5.9),p(-5.8,y0,5.9),p(-5.8,yr,wm),p(6.8,yr,wm),U0,C(0x9a9a96),FD(FH,0,-1,-1));
  [[-5,1],[6,-1]].forEach(function(q){P.tri(p(q[0],y0,-3.5),p(q[0],y0,5),p(q[0],yr-.05,wm),U0,RW,FD(FH,-q[1],0,0))});
  // kırmızı-beyaz tente (iki yüz) + saçak fırfırı: pist tarafı ve Akasya tarafı
  function awn(a,b,c,d,out){A.quad(a,b,c,d,AWN,ONE,out);A.quad(b,a,d,c,AWN,C(0xffffff,.8),[-out[0],-out[1],-out[2]])}
  awn(p(-5.2,2.35,-6.3),p(6.4,2.35,-6.3),p(6.4,3.05,-3.5),p(-5.2,3.05,-3.5),FD(FH,0,1,-.4));
  vplane(X,[p(-5.2,0,-6.3)[0],p(-5.2,0,-6.3)[2]],[p(6.4,0,-6.3)[0],p(6.4,0,-6.3)[2]],2.0,2.36,SC);
  awn(p(-7.9,2.35,5.2),p(-7.9,2.35,-6.3),p(-5,3.05,-6.3),p(-5,3.05,5.2),FD(FH,-.4,1,0));
  vplane(X,[p(-7.9,0,5.2)[0],p(-7.9,0,5.2)[2]],[p(-7.9,0,-6.3)[0],p(-7.9,0,-6.3)[2]],2.0,2.36,SC);
  [[-7.85,-6.25],[6.35,-6.25],[-7.85,5.1]].forEach(function(q){var pp=p(q[0],0,q[1]);pole(M,pp[0],pp[2],2.4,.04)});
  box(A,FH,-3,3,3.25,3.9,-3.8,-3.6,{nw:uvR(RG.S_CAY),pu:U0,nu:U0,t:WD},ONE);
  // masa-sandalyeler (turuncu/yeşil plastik)
  var CO=[C(0xe8622a),C(0x5cb648),C(0xf08a2a),C(0x4fa84a)],ci=0;
  [[-3.4,-5.0],[0.2,-4.9],[3.6,-5.1],[-6.6,-1.6],[-6.7,1.9]].forEach(function(t,ti){var q=p(t[0],0,t[1]),ang=Math.atan2(FH.u[1],FH.u[0])+rnd()*.4;table(P,q[0],q[2],ang);
   for(var k=0;k<4;k++){if(rnd()<.2)continue;var ca=ang+k*Math.PI/2+(rnd()-.5)*.5,cx=q[0]-Math.sin(ca)*.62,cz=q[2]+Math.cos(ca)*.62;chair(P,cx,cz,ca+Math.PI,CO[(ci++)%4])}});
  [[-7.4,-7.1],[1.5,-7.3],[-2.6,-7.2]].forEach(function(t){var q=p(t[0],0,t[1]);cone(P,q[0],q[2])});
  [[6.6,-5.4],[-7.4,3.8]].forEach(function(t){var q=p(t[0],0,t[1]);cyl(P,q[0],q[2],0,.45,.28,.22,8,U0,C(0x7a4a2e),{cap1:1})});})();
 // ---- ECZANE köşe binası (4 kat, gri sıva, zeytin yeşili zemin, turuncu cumba)
 var FE=Fr(W(15,-19.5),T,Lv,1),EU=uvR(RG.ECZU),EG=uvR(RG.ECZG),ES=uvR(RG.ECZS),CU=uvR(RG.CUMBA),TL=uvR(RG.TILE),RA=uvR(XR.RAIL,1,1);
 box(A,FE,-6.5,6.5,0,3.6,-5.5,5.5,{pw:EG,nu:EG,pu:sub(ES,0,.75,1,1),nw:sub(ES,0,.75,1,1)});
 box(A,FE,-7.2,6.5,3.6,13.2,-5.5,6.2,{pw:EU,nu:EU,pu:sub(ES,0,0,1,.75),nw:sub(ES,0,0,1,.75),b:GP});
 box(P,FE,-7.3,6.6,3.55,3.75,-5.6,6.3,{all:U0,b:U0},C(0x9b9e99));
 box(A,FE,-1.2,4.6,6.95,9.85,6.2,7.15,{pw:CU,pu:sub(CU,0,0,.2,1),nu:sub(CU,.8,0,1,1)});box(P,FE,-1.35,4.75,9.85,10.05,6.15,7.3,{all:U0,b:U0},C(0x7a4423));box(P,FE,-1.35,4.75,6.8,6.95,6.15,7.3,{all:U0,b:U0},C(0x7a4423));
 box(P,FE,-7.2,6.5,10.0,10.18,6.2,7.4,{all:U0,b:U0},C(0xa9aca6));
 (function(){var p=function(u,w){var q=FP(FE,u,0,w);return [q[0],q[2]]};vplane(X,p(-7.2,7.35),p(6.5,7.35),10.18,11.15,RA,C(0x777777));vplane(X,p(-7.2,6.2),p(-7.2,7.35),10.18,11.15,RA,C(0x777777));vplane(X,p(6.5,6.2),p(6.5,7.35),10.18,11.15,RA,C(0x777777))})();
 box(P,FE,-8.7,8.0,13.2,13.45,-6.9,8.9,{all:WD,b:U0},C(0x5c3a22));
 hip(A,FE,-8.7,8.0,-6.9,8.9,13.45,2.6,TL,ONE);
 box(A,FE,-1.4,3.4,2.75,3.5,5.5,5.8,{pw:uvR(RG.S_ECZ),pu:U0,nu:U0,t:U0,b:U0},ONE);
 box(A,FE,-6.8,-6.5,2.75,3.5,-3.5,1.3,{nu:uvR(RG.S_ECZ),pw:U0,nw:U0,t:U0,b:U0},ONE);
 box(A,FE,4.6,4.72,3.0,4.1,5.6,6.7,{pu:uvR(RG.S_E),nu:uvR(RG.S_E),pw:U0,t:U0,b:U0},ONE);
 box(P,FE,-6.5,6.5,0,.25,-5.5,5.5,{pw:U0,nu:U0},C(0x4a4f3c));
 // ---- MARKET (somon/beyaz, kemerli pencereler, lacivert branda, karpuz tezgâhı)
 var FK=Fr(W(-22.5,-20),T,Lv,1),MK=uvR(RG.MKT),MS=uvR(RG.MKTS);
 box(A,FK,-10,10,0,7.5,-6,6,{pw:MK,pu:MS,nu:MS,nw:MS});
 box(P,FK,-10.3,10.3,7.5,7.85,-6.3,6.3,{all:U0,b:U0},C(0xf4f1ec));box(P,FK,-10.15,10.15,3.9,4.1,-6.15,6.25,{pw:U0,pu:U0,nu:U0,t:U0,b:U0},C(0xf4f1ec));
 hip(A,FK,-10.9,10.9,-6.9,6.9,7.85,3.0,TL,ONE);
 box(A,FK,-1.9,1.9,7.85,10.0,3.3,5.2,{pw:uvR(RG.DORM),pu:MS,nu:MS},ONE);hip(A,FK,-2.3,2.3,2.9,5.7,10.0,1.2,TL,ONE);
 box(A,FK,-5.2,1.0,4.15,4.95,6.0,6.3,{pw:uvR(RG.S_MKT),pu:U0,nu:U0,t:U0,b:U0},ONE);
 box(A,FK,6.2,6.32,4.9,5.6,6.0,7.9,{pu:uvR(RG.S_MKT),nu:uvR(RG.S_MKT),pw:U0,t:U0,b:U0},ONE);
 (function(){var p=function(u,y,w){return FP(FK,u,y,w)},BR=C(0x6c4a3c),NB=C(0x1f2c5e);
  function two(K,a,b,c,d,col,out){K.quad(a,b,c,d,U0,col,out);K.quad(b,a,d,c,U0,[col[0]*.7,col[1]*.7,col[2]*.7],[-out[0],-out[1],-out[2]])}
  two(P,p(-2.6,3.25,7.7),p(4.2,3.25,7.7),p(4.2,3.85,6.0),p(-2.6,3.85,6.0),BR,FD(FK,0,1,.3));
  // branda: iki parça, sarkık
  two(P,p(-10,3.5,8.0),p(-3.1,3.5,8.0),p(-3.1,4.6,6.0),p(-10,4.6,6.0),NB,FD(FK,0,1,.5));
  two(P,p(-10,2.95,9.6),p(-3.1,2.95,9.6),p(-3.1,3.5,8.0),p(-10,3.5,8.0),NB,FD(FK,0,1,.3));
  [[-9.8,9.5],[-3.3,9.5]].forEach(function(q){var pp=p(q[0],0,q[1]);pole(M,pp[0],pp[2],2.98,.035)});
  // kasalar + karpuzlar
  var CR=uvR(RG.CRATE),ML=uvR(RG.MELON);
  for(var u=-9.6;u<-3.6;u+=.62){for(var w=6.25;w<8.7;w+=.45){var hgt=w<7?.66:.33;box(A,FK,u,u+.56,0,hgt,w,w+.4,{pu:CR,nu:CR,pw:CR,nw:CR,t:sub(CR,.1,.1,.9,.9)},ONE)}}
  for(var i=0;i<46;i++){var uu=-9.4+rnd()*5.6,ww=6.3+rnd()*2.3,base=ww<7?.66:.33,q=p(uu,0,ww);sphere(A,q[0],base+.17+rnd()*.12,q[2],.17+rnd()*.05,6,ML,ONE)}
  // turunç/domates kasaları kapı yanında
  for(var j=0;j<6;j++){var u2=4.5+j%3*.62,w2=6.3+(j>2?.45:0);box(A,FK,u2,u2+.56,0,.5,w2,w2+.4,{pu:CR,nu:CR,pw:CR,nw:CR},C(0x9a9a9a));
   for(var k=0;k<5;k++){var q2=p(u2+.1+rnd()*.36,0,w2+.08+rnd()*.24);sphere(P,q2[0],.56,q2[2],.06,4,U0,j%2?C(0xe8862a):C(0xc8302a))}}
  P.quad(p(-2.4,.18,6.0),p(1.6,.18,6.0),p(1.6,.18,7.3),p(-2.4,.18,7.3),U0,C(0x3f8a3a),UP);
  for(var u3=-9.6;u3<-3.6;u3+=.62)ob(-22.5+u3+.3,-20+7.4,.6);})();
 // ---- trafik levhaları: tek yön (mavi), İstanbul yön levhası, trafik aynası
 (function(){var q=W(6.6,-12.2);pole(M,q[0],q[1],3.1,.045);var F=frAng(q[0],q[1],Math.atan2(Lv[1],Lv[0])+Math.PI/2,1);
  box(A,F,-.32,.32,2.35,2.99,-.03,.03,{nw:uvR(RG.ONEW),pw:GP,pu:GP,nu:GP},ONE);box(A,F,-.55,.55,1.85,2.25,-.03,.03,{nw:uvR(RG.IST),pw:GP},ONE);addOb(q[0],q[1],.15);
  var m=W(-6.7,-12.4);pole(M,m[0],m[1],3.2,.05,C(0xd8641e));var Fm=frAng(m[0],m[1],Math.atan2(Lv[1],Lv[0])+Math.PI*.75,1);
  box(M,Fm,-.05,.05,2.9,3.05,-.05,.3,{all:U0},C(0x333333));var c=FP(Fm,0,0,.34);
  for(var k=0;k<10;k++){var a0=k/10*Math.PI*2,a1=(k+1)/10*Math.PI*2,R0=.38;var o=function(a,r){return FP(Fm,Math.cos(a)*r,3.0+Math.sin(a)*r,.34)};
   M.quad(o(a0,R0),o(a1,R0),o(a1,R0*.86),o(a0,R0*.86),U0,C(0xd8641e),FD(Fm,0,0,1));M.tri(FP(Fm,0,3.0,.36),o(a0,R0*.86),o(a1,R0*.86),U0,C(0xe8eef2),FD(Fm,0,0,1));M.tri(FP(Fm,0,3.0,.3),o(a1,R0),o(a0,R0),U0,C(0x333333),FD(Fm,0,0,-1))}
  addOb(m[0],m[1],.15)})();
 SOLID.forEach(function(f){f()});STAT.solid=solidN; // [AJAN:polish]
 flush(KS,scene,'kavsak');
 // ---- dev çınarlar (kavşak + dere boyu)
 BIG.length=0;
 [[-15.5,15.6],[-27,15.2],[-38,15.8],[-43,40],[-30,44],[25.5,14.6],[8.2,14.4],[11,29],[23.5,31.5],[-8.5,-13.2],[-36,-13.4],[23,-13.5],[28,-27],[-28,-31],[-41,-20],[40,-26],[44,22],[52,-18],[36,32],[58,14],[-20.5,15.4],[-24,43.5]].forEach(function(q,i){var w=W(q[0],q[1]);if(ctx.minRoadDist&&ctx.minRoadDist(w[0],w[1])<13.2||roadDist(w[0],w[1])<1.2)return; /*[AJAN:polish] yolun ortasındaki çınarlar*/BIG.push([w[0],w[1],1.0+rnd()*.3,i<10?1:0])});
 if(ctx.water)ctx.water.forEach(function(P2){for(var i=0;i<P2.length-1;i++){var a=P2[i],b=P2[i+1],L=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.floor(L/11);for(var k=0;k<=n;k++){var x=a[0]+(b[0]-a[0])*k/n,z=a[1]+(b[1]-a[1])*k/n;if(Math.hypot(x-J[0],z-J[1])>240)continue;
   var tx=(b[0]-a[0])/L,tz=(b[1]-a[1])/L;[1,-1].forEach(function(sg){if(rnd()<.35)return;var o=6.2+rnd()*2.5,px=x-tz*o*sg,pz=z+tx*o*sg;if(ctx.minRoadDist(px,pz)<11.5+3)return;if(roadDist(px,pz)<5.5)return;
    var q=AL(px,pz);if(inEx(px,pz,0))return;BIG.push([px,pz,.85+rnd()*.35,0])})}}});
 // ---- Akasya / Ş.A.Akyol evleri: balkonlar, çanak antenler, asmalar
 houses(ctx);
}
var BIG=[];
// ---- ev donatıları
function houses(ctx){var KS=kits(),P=KS.P,X=KS.X,RA=uvR(XR.RAIL,1,1),dish=[],vine=[];
 var DD=[.26,0,.966];
 ZH.forEach(function(h){var cx=h[0],cz=h[1],tx=h[2],tz=h[3],w=h[4],d=h[5],fl=h[6],fs=h[10],yard=h[11],ty=h[15],H=fl*3;
  var lx=tz,lz=-tx,fx=-lx*fs,fz=-lz*fs,F=Fr([cx,cz],[tx,tz],[fx,fz],1);
  if(ty===1){var bw=w/2-.15,rc=rnd()<.5?C(0x6b4a3a):C(0x8a8e92);
   for(var f=1;f<fl;f++){var y=f*3;box(P,F,-bw,bw,y-.2,y,d/2,d/2+1.3,{all:U0,b:U0},C(0xe8e3d8));
    var p=function(u,ww){var q=FP(F,u,0,ww);return [q[0],q[2]]};vplane(X,p(-bw,d/2+1.25),p(bw,d/2+1.25),y,y+1.0,RA,rc);vplane(X,p(-bw,d/2),p(-bw,d/2+1.25),y,y+1.0,RA,rc);vplane(X,p(bw,d/2),p(bw,d/2+1.25),y,y+1.0,RA,rc);
    if(rnd()<.45){var du=(rnd()-.5)*(w-2.5);dish.push([FP(F,du,y+1.1,d/2+1.05),.5+rnd()*.25])}}}
  else if(rnd()<.6){// en güneye bakan duvara çanak
   var best=null,bd=-9;[[1,0],[-1,0],[0,1],[0,-1]].forEach(function(q){var n=FD(F,q[0],0,q[1]);var v=n[0]*DD[0]+n[2]*DD[2];if(v>bd){bd=v;best=q}});
   var off=best[0]?w/2+.45:d/2+.45,pp=best[0]?FP(F,best[0]*off,H-.9,(rnd()-.5)*d*.5):FP(F,(rnd()-.5)*w*.5,H-.9,best[1]*off);dish.push([pp,.45+rnd()*.2])}
  // asma / yeşillik: bahçe duvarı boyunca ve kapı üstünde
  if(yard>1.4&&(ty===5||rnd()<.45)){var n=1+Math.floor(rnd()*(ty===5?3:2));for(var i=0;i<n;i++){var u=(rnd()-.5)*(h[12]-2),wq=d/2+yard-.5;var q=FP(F,u,0,wq);vine.push([q[0],q[2],1.6+rnd()*1.6,1.0+rnd()*.9,ty===5?.9:.45])}}
  if(ty===5&&rnd()<.7){var q2=FP(F,(rnd()-.5)*w*.6,0,d/2+.4);vine.push([q2[0],q2[2],2.4+rnd(),1.4+rnd()*.6,1.9])}});
 ZB.forEach(function(b){var cx=b[0],cz=b[1],tx=b[2],tz=b[3],w=b[4],d=b[5],H=b[6],fl=Math.round(H/3),lx=tz,lz=-tx;
  // sokağa en yakın uzun cepheyi bul
  var best=null,bd=1e9;[[0,1],[0,-1]].forEach(function(q){var fx=lx*q[1],fz=lz*q[1],px=cx+fx*d/2,pz=cz+fz*d/2,dd=Math.min(segD(px,pz,AK),segD(px,pz,SA));if(dd<bd){bd=dd;best=q[1]}});
  var F=Fr([cx,cz],[tx,tz],[lx*best,lz*best],1),bw=w/2-.6,rc=rnd()<.5?C(0x6b4a3a):C(0x8a8e92);
  for(var f=1;f<fl;f++){var y=f*3;if(rnd()<.15)continue;box(P,F,-bw,bw,y-.2,y,d/2,d/2+1.3,{all:U0,b:U0},C(0xe8e3d8));
   var p=function(u,ww){var q=FP(F,u,0,ww);return [q[0],q[2]]};vplane(X,p(-bw,d/2+1.25),p(bw,d/2+1.25),y,y+1.0,RA,rc);vplane(X,p(-bw,d/2),p(-bw,d/2+1.25),y,y+1.0,RA,rc);vplane(X,p(bw,d/2),p(bw,d/2+1.25),y,y+1.0,RA,rc);
   if(rnd()<.5)dish.push([FP(F,(rnd()-.5)*(w-3),y+1.1,d/2+1.05),.5+rnd()*.25])}});
 flush(KS,ctx.scene,'evler');
 // çanak anten (InstancedMesh)
 if(dish.length){var g=dishGeo(),im=new THREE.InstancedMesh(g,new THREE.MeshStandardMaterial({color:0xd9dcdf,roughness:.5,metalness:.25,side:THREE.DoubleSide}),dish.length),dm=new THREE.Object3D();dm.rotation.order='YXZ';
  dish.forEach(function(q,i){dm.position.set(q[0][0],q[0][1],q[0][2]);dm.rotation.set(-.7,Math.atan2(DD[0],DD[2]),0);dm.scale.setScalar(q[1]/.5);dm.updateMatrix();im.setMatrixAt(i,dm.matrix)});im.castShadow=true;ctx.scene.add(im);STAT.calls++;STAT.tris+=g.attributes.position.count/3*dish.length;STAT.items.push('canak x'+dish.length+':'+g.attributes.position.count/3*dish.length)}
 VINE=vine}
var VINE=[];
function dishGeo(){var parts=[],S=new THREE.SphereGeometry(.5,10,2,0,Math.PI*2,0,.62);S.rotateX(-Math.PI/2);S.translate(0,0,.5);parts.push(S);
 var a=new THREE.CylinderGeometry(.018,.018,.62,4);a.rotateX(Math.PI/2+.35);a.translate(0,-.12,.33);parts.push(a);var l=new THREE.BoxGeometry(.07,.07,.12);l.translate(0,-.22,.6);parts.push(l);
 var m=new THREE.CylinderGeometry(.025,.025,.5,4);m.rotateX(Math.PI/2);m.translate(0,0,-.2);parts.push(m);return mergeNI(parts)}
function mergeNI(list){var p=[],n=[];list.forEach(function(g){var q=g.index?g.toNonIndexed():g;var a=q.attributes.position.array,b=q.attributes.normal.array;for(var i=0;i<a.length;i++){p.push(a[i]);n.push(b[i])}});
 var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(n,3));return g}

// ================= 7) AĞAÇLAR (tüm oyun) =================
function leafTex(){var S=256,c=cv(S,S),g=c.getContext('2d');g.clearRect(0,0,S,S);
 // kart dokusu: düzensiz alt-kümelerden oluşan, kenarı dağınık yaprak öbeği (alfa). Çınar yaprağı: 5 loblu.
 function leaf(x,y,s,a,col){g.save();g.translate(x,y);g.rotate(a);g.fillStyle=col;g.beginPath();
  for(var k=0;k<5;k++){var an=-Math.PI/2+(k-2)*.6,r=s*(k===2?1:.8);g.lineTo(Math.cos(an)*r,Math.sin(an)*r);g.lineTo(Math.cos(an+.3)*r*.42,Math.sin(an+.3)*r*.42)}g.lineTo(0,s*.3);g.closePath();g.fill();g.restore()}
 var sub=[];for(var i=0;i<9;i++){var a=rnd()*6.28,r=Math.sqrt(rnd())*70;sub.push([128+Math.cos(a)*r,128+Math.sin(a)*r*.9,26+rnd()*30])}sub.push([128,128,48]);
 // gölgeli alt katman, sonra ışıklı üst yapraklar
 for(var pass=0;pass<2;pass++)for(i=0;i<(pass?2600:1800);i++){var sb_=sub[Math.floor(rnd()*sub.length)],an=rnd()*6.28,rr=Math.pow(rnd(),.7)*sb_[2],x=sb_[0]+Math.cos(an)*rr,y=sb_[1]+Math.sin(an)*rr;
  if(x<4||x>252||y<4||y>252)continue;var lt=((128-y)/128*.6+(128-x)/128*.2)*(pass?1:.4);
  var L=(pass?33:27)+lt*13+rnd()*9,H=72+rnd()*28,Sa=40+rnd()*25;leaf(x,y,3.2+rnd()*2.6,rnd()*6.3,'hsl('+H+','+Sa+'%,'+L+'%)')}
 for(i=0;i<60;i++){g.strokeStyle='rgba(80,64,48,.7)';g.lineWidth=1;g.beginPath();var x0=128+(rnd()-.5)*150,y0=128+(rnd()-.5)*140;g.moveTo(x0,y0);g.lineTo(x0+(rnd()-.5)*24,y0+(rnd()-.5)*24);g.stroke()}
 var t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;t.anisotropy=4;return t}
var LEAFM=null;
function leafMat(){if(LEAFM)return LEAFM;LEAFM=new THREE.MeshLambertMaterial({map:leafTex(),alphaTest:.45,side:THREE.DoubleSide,vertexColors:true});
 // çift yüzlü kartlarda arka yüz normalini çevirme (küresel yumuşak ışık kalsın)
 LEAFM.onBeforeCompile=function(s){s.fragmentShader=s.fragmentShader.replace('#include <normal_fragment_begin>','#include <normal_fragment_begin>\n normal=normalize(vNormal);')};return LEAFM}
// taç kümesi: n kart + iç gövde
function crown(T,cx,cy,cz,rx,ry,n,cs,core,dark){var V=T.p,N=T.n,U=T.u,Cc=T.c;
 function push(p,nn,u,c){V.push(p[0],p[1],p[2]);N.push(nn[0],nn[1],nn[2]);U.push(u[0],u[1]);Cc.push(c,c,c)}
 for(var i=0;i<n;i++){var th=rnd()*Math.PI*2,ph=Math.acos(2*rnd()-1),dx=Math.sin(ph)*Math.cos(th),dy=Math.cos(ph),dz=Math.sin(ph)*Math.sin(th),k=.35+Math.sqrt(rnd())*.6;
  var c=[cx+dx*rx*k,cy+dy*ry*k*.8,cz+dz*rx*k],s=cs*(.8+rnd()*.4);
  // rastgele yönlü kart
  var a=rnd()*Math.PI,b=(rnd()-.5)*1.2,ax=[Math.cos(a),0,Math.sin(a)],ay=[-Math.sin(a)*Math.sin(b),Math.cos(b),Math.cos(a)*Math.sin(b)];
  var Pq=[[-1,-1],[1,-1],[1,1],[-1,1]].map(function(o){return [c[0]+(ax[0]*o[0]+ay[0]*o[1])*s/2,c[1]+(ax[1]*o[0]+ay[1]*o[1])*s/2,c[2]+(ax[2]*o[0]+ay[2]*o[1])*s/2]});
  var Uq=[[0,0],[1,0],[1,1],[0,1]];
  var Nq=Pq.map(function(p){return nr([(p[0]-cx)/rx,(p[1]-cy)/ry*.7+.75,(p[2]-cz)/rx])});
  var Cq=Pq.map(function(p){return .8+.2*Math.max(0,Math.min(1,(p[1]-cy+ry)/(2*ry)))*(1-dark)});
  [0,1,2,0,2,3].forEach(function(j){push(Pq[j],Nq[j],Uq[j],Cq[j])})}
 if(core){var ic=new THREE.IcosahedronGeometry(1,0),pa=ic.attributes.position;
  for(var j=0;j<pa.count;j+=3){var tri=[0,1,2].map(function(q){return [pa.getX(j+q),pa.getY(j+q),pa.getZ(j+q)]});var uc=[.1+rnd()*.8,.03+rnd()*.15];
   tri.forEach(function(v,q){var p=[cx+v[0]*rx*core,cy+v[1]*ry*core*.85,cz+v[2]*rx*core];push(p,nr([v[0],v[1]+.3,v[2]]),[uc[0]+q*.05,uc[1]+(q===2?.04:0)],.5+.25*(v[1]+1)/2)})}}}
function trunkGeo(big){var T=new Kit(),bc=big?C(0x7d7666):C(0x4e3e2e);
 if(big){cyl(T,0,0,0,7.6,.5,.3,7,U0,bc,{});
  [[0,5.2,.9],[2.1,5.8,.8],[4.2,4.9,.85],[1.1,6.6,.6],[5.3,6.2,.6]].forEach(function(b){var an=b[0],y=b[1],L=4.2*b[2],ex=Math.cos(an)*L*.75,ez=Math.sin(an)*L*.75;
   var ax=nr([ex,L*.66,ez]);// eğik dal: kısa silindir dizisi
   var p0=[0,y,0],p1=[ex,y+L*.66,ez],r0=.17*b[2],r1=.05;
   for(var k=0;k<5;k++){var t0=k/5,t1=(k+1)/5,a0=k/5*Math.PI*2,a1=(k+1)/5*Math.PI*2;var perp=nr(cr(ax,[0,1,0])),perp2=cr(ax,perp);
    var Pt=function(t,a,r){return [p0[0]+(p1[0]-p0[0])*t+(perp[0]*Math.cos(a)+perp2[0]*Math.sin(a))*r,p0[1]+(p1[1]-p0[1])*t+(perp[1]*Math.cos(a)+perp2[1]*Math.sin(a))*r,p0[2]+(p1[2]-p0[2])*t+(perp[2]*Math.cos(a)+perp2[2]*Math.sin(a))*r]};
    T.quad(Pt(0,a0,r0),Pt(0,a1,r0),Pt(1,a1,r1),Pt(1,a0,r1),U0,bc,nr([perp[0]*Math.cos((a0+a1)/2)+perp2[0]*Math.sin((a0+a1)/2),perp[1]*Math.cos((a0+a1)/2)+perp2[1]*Math.sin((a0+a1)/2),perp[2]*Math.cos((a0+a1)/2)+perp2[2]*Math.sin((a0+a1)/2)]))}})}
 else{cyl(T,0,0,0,3.4,.2,.13,6,U0,bc,{});[[0.5,2.6],[3.4,2.9]].forEach(function(b){var ex=Math.cos(b[0])*1.1,ez=Math.sin(b[0])*1.1;
   var p0=[0,b[1],0],p1=[ex,b[1]+1.3,ez],ax=nr(sb(p1,p0)),pe=nr(cr(ax,[0,1,0])),p2=cr(ax,pe);
   for(var k=0;k<4;k++){var a0=k/4*Math.PI*2,a1=(k+1)/4*Math.PI*2,r0=.08,r1=.04,Pt=function(t,a,r){return [p0[0]+(p1[0]-p0[0])*t+(pe[0]*Math.cos(a)+p2[0]*Math.sin(a))*r,p0[1]+(p1[1]-p0[1])*t+(pe[1]*Math.cos(a)+p2[1]*Math.sin(a))*r,p0[2]+(p1[2]-p0[2])*t+(pe[2]*Math.cos(a)+p2[2]*Math.sin(a))*r]};
    T.quad(Pt(0,a0,r0),Pt(0,a1,r0),Pt(1,a1,r1),Pt(1,a0,r1),U0,bc,nr([pe[0]*Math.cos(a0)+p2[0]*Math.sin(a0),pe[1]*Math.cos(a0)+p2[1]*Math.sin(a0),pe[2]*Math.cos(a0)+p2[2]*Math.sin(a0)]))}})}
 var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(T.p,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(T.n,3));g.setAttribute('color',new THREE.Float32BufferAttribute(T.c,3));return g}
// [AJAN:polish] kart sırasını (6 köşe/kart) sabit tohumla karıştır → setDrawRange öneki dengeli seyreltme verir (kalite LOD)
function cardShuffle(T){var n=T.p.length/18,o=[],i,s=1234567;for(i=0;i<n;i++)o.push(i);for(i=n-1;i>0;i--){s=(s*1103515245+12345)&0x7fffffff;var j=s%(i+1),t=o[i];o[i]=o[j];o[j]=t}
 [['p',3],['n',3],['u',2],['c',3]].forEach(function(q){var A=T[q[0]],w=q[1]*6,B=new Array(A.length);for(var k=0;k<n;k++)for(var e=0;e<w;e++)B[k*w+e]=A[o[k]*w+e];T[q[0]]=B})}
function crownGeo(kind){var T={p:[],n:[],u:[],c:[]};
 if(kind==='big'){// çınar: geniş, düzensiz, yüksek taç (gövde 0-7 m, taç ~6-18 m)
  crown(T,0,12.5,0,5.6,4.2,26,4.0,0,0);crown(T,3.6,10.2,1.6,3.8,3.0,12,3.4,0,.12);crown(T,-3.4,10.6,-1.9,3.8,3.2,12,3.4,0,.12);
  crown(T,1.0,9.4,-3.9,3.4,2.8,10,3.2,0,.2);crown(T,-1.8,9.0,3.6,3.4,2.8,10,3.2,0,.2);crown(T,.6,16.0,.4,3.6,2.4,10,3.2,0,0);crown(T,4.6,13.2,-1.2,2.6,2.4,7,2.8,0,.05)}
 else if(kind==='vine'){crown(T,0,.55,0,.6,.5,8,.85,0,.2)}
 else{crown(T,0,5.1,0,2.4,2.0,12,2.3,0,.05);crown(T,.9,4.1,.6,1.7,1.4,6,1.9,0,.2)}
 cardShuffle(T); // [AJAN:polish]
 var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(T.p,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(T.n,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(T.u,2));g.setAttribute('color',new THREE.Float32BufferAttribute(T.c,3));return g}
// [AJAN:polish] ---- ağaç LOD: kaliteye göre yaprak kartı oranı + çizim mesafesi (Ultra/Yüksek: tam; Orta: %70 kart, 190 m; Düşük: %50 kart, 130 m)
var TL=[],TLQ=[[1,0],[1,0],[.7,190],[.5,130]];
function treeLayer(tr,cr,list,rk){if(!cr)return;TL.push({tr:tr,cr:cr,n:list.length,rk:rk,pos:list.map(function(q){return [q[0],q[1]]}),mt:tr?tr.instanceMatrix.array.slice():null,mc:cr.instanceMatrix.array.slice(),
  cc:cr.instanceColor?cr.instanceColor.array.slice():null,full:cr.geometry.attributes.position.count,q:-1,all:true})}
function treeLOD(qi,x,z){var Q=TLQ[qi]||TLQ[3];
 for(var li=0;li<TL.length;li++){var L=TL[li];
  if(L.q!==qi){L.q=qi;L.cr.geometry.setDrawRange(0,Math.max(6,Math.floor(L.full/6*Q[0])*6))}
  if(!Q[1]){if(!L.all){L.all=true;L.cr.instanceMatrix.array.set(L.mc);L.cr.count=L.n;L.cr.instanceMatrix.needsUpdate=true;if(L.cc){L.cr.instanceColor.array.set(L.cc);L.cr.instanceColor.needsUpdate=true}
    if(L.tr){L.tr.instanceMatrix.array.set(L.mt);L.tr.count=L.n;L.tr.instanceMatrix.needsUpdate=true}}continue}
  var R2=Q[1]*L.rk*Q[1]*L.rk,k=0,a=L.cr.instanceMatrix.array,c=L.cc?L.cr.instanceColor.array:null,t=L.tr?L.tr.instanceMatrix.array:null;
  for(var i=0;i<L.n;i++){var dx=L.pos[i][0]-x,dz=L.pos[i][1]-z;if(dx*dx+dz*dz>R2)continue;
   for(var e=0;e<16;e++){a[k*16+e]=L.mc[i*16+e];if(t)t[k*16+e]=L.mt[i*16+e]}
   if(c){c[k*3]=L.cc[i*3];c[k*3+1]=L.cc[i*3+1];c[k*3+2]=L.cc[i*3+2]}k++}
  L.all=false;L.cr.count=k;L.cr.instanceMatrix.needsUpdate=true;if(c)L.cr.instanceColor.needsUpdate=true;if(t){L.tr.count=k;L.tr.instanceMatrix.needsUpdate=true}}}
// tp: [[x,z,y],...] (index.html stepProps'tan). Kavşak çevresindeki kaldırım ağaçlarını dev çınarlar ile değiştirir.
function trees(ctx,tp){var scene=ctx.scene,addOb=ctx.addOb||function(){},dm=new THREE.Object3D(),col=new THREE.Color();
 tp=tp.filter(function(q){var a=AL(q[0],q[1]);return !(Math.abs(a[0])<50&&Math.abs(a[1])<13)&&!inEx(q[0],q[1],.5)});
 function inst(geo,mat,list,f,cast){if(!list.length)return null;var im=new THREE.InstancedMesh(geo,mat,list.length);list.forEach(function(q,i){f(q,i,im)});im.castShadow=!!cast;scene.add(im);var t=(geo.index?geo.index.count:geo.attributes.position.count)/3;STAT.calls++;STAT.tris+=t*list.length;STAT.items.push('agac('+t+'x'+list.length+'):'+t*list.length);return im}
 var LM_=leafMat(),bark=new THREE.MeshLambertMaterial({vertexColors:true});
 var sg=trunkGeo(false),cg=crownGeo('small'),rs=[];
 tp.forEach(function(q){rs.push([R2(),.8+R2()*.6,R2()])});
 function R2(){return rnd()}
 var t1=inst(sg,bark,tp,function(q,i,im){dm.position.set(q[0],q[2],q[1]);dm.rotation.set(0,rs[i][0]*6.28,0);dm.scale.setScalar(rs[i][1]);dm.updateMatrix();im.setMatrixAt(i,dm.matrix);if(q[2]>0)addOb(q[0],q[1],.3)});
 var c1=inst(cg,LM_,tp,function(q,i,im){dm.position.set(q[0],q[2],q[1]);dm.rotation.set(0,rs[i][0]*6.28,0);dm.scale.setScalar(rs[i][1]);dm.updateMatrix();im.setMatrixAt(i,dm.matrix);col.setHSL(.2+rs[i][2]*.07,.35+rs[i][2]*.2,.62+rs[i][2]*.18);im.setColorAt(i,col)});
 // dev çınarlar
 var bg=trunkGeo(true),bc=crownGeo('big');
 var bt=inst(bg,bark,BIG,function(q,i,im){dm.position.set(q[0],0,q[1]);dm.rotation.set(0,i*2.39,0);dm.scale.setScalar(q[2]);dm.updateMatrix();im.setMatrixAt(i,dm.matrix);addOb(q[0],q[1],.6*q[2])},true);
 var c2=inst(bc,LM_,BIG,function(q,i,im){dm.position.set(q[0],0,q[1]);dm.rotation.set(0,i*2.39,0);dm.scale.setScalar(q[2]);dm.updateMatrix();im.setMatrixAt(i,dm.matrix);col.setHSL(.2+(i%5)*.012,.5,.78+(i%3)*.05);im.setColorAt(i,col)},true);
 // asmalar / bahçe yeşillikleri
 var vg=crownGeo('vine');
 var c3=inst(vg,LM_,VINE,function(q,i,im){dm.position.set(q[0],0,q[1]);dm.rotation.set(0,i*1.7,0);dm.scale.set(q[2],q[4],q[3]);dm.updateMatrix();im.setMatrixAt(i,dm.matrix);col.setHSL(.24,.5,.62+(i%4)*.05);im.setColorAt(i,col)});
 dm.scale.set(1,1,1);
 treeLayer(t1,c1,tp,1);treeLayer(bt,c2,BIG,1.6);treeLayer(null,c3,VINE,.6)} // [AJAN:polish] kalite LOD katmanları

// ================= 8) KÖPRÜ KORKULUĞU (çelik üçgen kafes + yeşil boru) =================
function bridge(ctx){var BR=ctx.JCUT.BR,NS=ctx.NS,pts=ctx.pts,lefts=ctx.lefts,HALF=ctx.HALF,SW=ctx.SW,KS=kits(),M=KS.M,P=KS.P;if(!MT)MT=mats(ctx.NIGHT);
 var runs=[],cur=null;for(var i=0;i<NS;i++){if(BR[i]){if(!cur){cur=[i,i];runs.push(cur)}else cur[1]=i}else cur=null}
 var ST=C(0x2e2a27),GR=C(0x3f8a48);
 function bar(p0,p1,t,col){// kesit t, p0->p1 kutu
  var d=sb(p1,p0),L=Math.hypot(d[0],d[1],d[2]);if(L<1e-3)return;var ax=nr(d),s=Math.abs(ax[1])<.95?[0,1,0]:[1,0,0],e1=nr(cr(ax,s)),e2=cr(ax,e1),h=t/2;
  var c=function(p,a,b){return [p[0]+e1[0]*a*h+e2[0]*b*h,p[1]+e1[1]*a*h+e2[1]*b*h,p[2]+e1[2]*a*h+e2[2]*b*h]};
  [[[-1,-1],[1,-1]],[[1,-1],[1,1]],[[1,1],[-1,1]],[[-1,1],[-1,-1]]].forEach(function(q){var mid=[(q[0][0]+q[1][0])/2,(q[0][1]+q[1][1])/2],out=[e1[0]*mid[0]+e2[0]*mid[1],e1[1]*mid[0]+e2[1]*mid[1],e1[2]*mid[0]+e2[2]*mid[1]];
   M.quad(c(p0,q[0][0],q[0][1]),c(p0,q[1][0],q[1][1]),c(p1,q[1][0],q[1][1]),c(p1,q[0][0],q[0][1]),U0,col,out)})}
 runs.forEach(function(r){[1,-1].forEach(function(sg){var latT=sg*(HALF+SW-.3),latG=sg*(HALF+SW-1.25),P0=[],G0=[];
   for(var k=r[0];k<=r[1];k++){var p=pts[k],l=lefts[k];P0.push([p.x+l.x*latT,p.z+l.z*latT]);G0.push([p.x+l.x*latG,p.z+l.z*latG])}
   // yaklaşık 2.2 m panel
   var acc=[0];for(var i=1;i<P0.length;i++)acc.push(acc[i-1]+Math.hypot(P0[i][0]-P0[i-1][0],P0[i][1]-P0[i-1][1]));var Ltot=acc[acc.length-1],np=Math.max(2,Math.round(Ltot/2.2));
   function at(Arr,s){for(var i=1;i<Arr.length;i++)if(acc[i]>=s){var t=(s-acc[i-1])/((acc[i]-acc[i-1])||1);return [Arr[i-1][0]+(Arr[i][0]-Arr[i-1][0])*t,Arr[i-1][1]+(Arr[i][1]-Arr[i-1][1])*t]}return Arr[Arr.length-1]}
   var yb=.3,yt=1.45;
   for(var j=0;j<np;j++){var a=at(P0,Ltot*j/np),b=at(P0,Ltot*(j+1)/np),m=at(P0,Ltot*(j+.5)/np);
    bar([a[0],yb,a[1]],[b[0],yb,b[1]],.12,ST);bar([a[0],yt,a[1]],[b[0],yt,b[1]],.12,ST);
    bar([a[0],yb,a[1]],[m[0],yt,m[1]],.08,ST);bar([m[0],yt,m[1]],[b[0],yb,b[1]],.08,ST);
    bar([a[0],.17,a[1]],[a[0],yt+.06,a[1]],.1,ST)}
   var e=at(P0,Ltot);bar([e[0],.17,e[1]],[e[0],yt+.06,e[1]],.1,ST);
   // yeşil boru korkuluk
   var ng=Math.max(2,Math.round(Ltot/2.5));for(j=0;j<ng;j++){var g0=at(G0,Ltot*j/ng),g1=at(G0,Ltot*(j+1)/ng);[.62,1.0].forEach(function(y){bar([g0[0],y,g0[1]],[g1[0],y,g1[1]],.07,GR)});bar([g0[0],.17,g0[1]],[g0[0],1.06,g0[1]],.07,GR)}
   var ge=at(G0,Ltot);bar([ge[0],.17,ge[1]],[ge[0],1.06,ge[1]],.07,GR);
   if(ctx.addOb){var nso=Math.ceil(Ltot/1.0);for(j=0;j<=nso;j++){var so=at(G0,Ltot*j/nso);ctx.addOb(so[0],so[1],.12,'solid')}} // [AJAN:polish] yeşil boru korkuluk katı (araç gövdesi korkuluğa ~1 m giriyordu)
   // köprü başı beton ayaklar
   [P0[0],P0[P0.length-1]].forEach(function(q){box(P,frAng(q[0],q[1],0,1),-.35,.35,0,1.6,-.35,.35,{pu:U0,nu:U0,pw:U0,nw:U0,t:U0},C(0x9c9890))})})});
 flush(KS,ctx.scene,'kopru')}
// jenerik cami (OSM poligonundan): en uzun kenara hizalı, poligona sığacak ölçekte
function mosqueFromPoly(ctx,P){if(!MT)useMats(ctx.NIGHT);var KS=kits(),n=P.length,bi=0,bl=0,cx=0,cz=0;for(var i=0;i<n;i++){var a=P[i],b=P[(i+1)%n],l=Math.hypot(b[0]-a[0],b[1]-a[1]);if(l>bl){bl=l;bi=i}cx+=a[0]/n;cz+=a[1]/n}
 var a=P[bi],b=P[(bi+1)%n],ux=(b[0]-a[0])/bl,uz=(b[1]-a[1])/bl,mu=0,mw=0;P.forEach(function(p){var du=(p[0]-cx)*ux+(p[1]-cz)*uz,dw=(p[0]-cx)*-uz+(p[1]-cz)*ux;mu=Math.max(mu,Math.abs(du));mw=Math.max(mw,Math.abs(dw))});
 var s=Math.max(.45,Math.min(mu,mw)/12.5);mosque(KS,Fr([cx,cz],[ux,uz],[-uz,ux],s),{mu:9.4,mw:-9.4});flush(KS,ctx.scene,'cami2')}

return {build:build,trees:trees,treeLOD:treeLOD,bridge:bridge,mosqueFromPoly:mosqueFromPoly,W:W,AL:AL,inEx:inEx,STAT:STAT,ZH:ZH,BIG:BIG,
 houseCols:['#ebb46c','#efc1b0','#e6e6e2','#a9c6bb','#e8c97c']};
})();
