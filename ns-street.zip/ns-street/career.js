// [AJAN:career] Kara Liste + yarış takvimi verisi (sadece veri; mantık index.html içindeki KARİYER bloğunda)
// Tüm isimler kurgusaldır. Harita kimlikleri: 'mithatpasa' (OSM Mithatpaşa), 'liman' (eski kurgusal şehir), 'sapanca' (Sapanca Otoyolu, O-4)
var NS_CAREER=(function(){
 var MAPS={mithatpasa:{n:'Mithatpaşa',s:'Mahalle'},liman:{n:'Liman',s:'Sahil · otoyol · tünel'},sapanca:{n:'Sapanca',s:'Göl kenarı O-4 otoyolu'}};
 var TYPES={circuit:{n:'Devre',d:'Birkaç tur, ilk gelen kazanır'},sprint:{n:'Sprint',d:'A noktasından B noktasına'},elim:{n:'Eleme',d:'Her bölümde sonuncu elenir'},
  speed:{n:'Hız Kapanı',d:'Radarlardaki hızların toplamı'},lap:{n:'Tur Rekoru',d:'En hızlı tek tur kazanır'}};
 // #15 → #1 (dizi sırası: 0 = #15)
 var BL=[
  {nick:'Taksici',name:'Hayati Bozkurt',car:'murat',col:0xe9c21b,line:'Taksimetre açık abi. Geç kalırsan farkı sen ödersin.'},
  {nick:'Çırak',name:'Emrah Kuşçu',car:'dogan',col:0xd9d9d9,line:'Ustam bu Doğan’ı bana emanet etti, çizdirme sakın.'},
  {nick:'Kestane',name:'Burak Erenler',car:'dogan',col:0x7a4a2a,line:'Erenler’den buraya kadar beni geçen olmadı.'},
  {nick:'Fındık',name:'Sinan Kocaalili',car:'astra',col:0xe8dcc0,line:'Virajda fındık toplar gibi toplarım sizi.'},
  {nick:'Vagon',name:'Rıza Demirci',car:'saratoga',col:0x2d6f9a,line:'Vagon gibi ağırım ama durdurması imkânsız.'},
  {nick:'Islama',name:'Kadir Köfteci',car:'ae86',col:0xc11c22,line:'Köfteyi ıslatırım, rakibi kuruturum.'},
  {nick:'Dere',name:'Tuncay Çark',car:'s180',col:0xffa623,line:'Çark Suyu gibi akarım, önüme set çekemezsin.'},
  {nick:'Sapanca',name:'Deniz Gölcük',car:'camaro',col:0x1d5fd6,line:'Sabah göl kenarında çay, gece senin yenilgin.'},
  {nick:'Hendek',name:'Okan Yalçın',car:'z32',col:0x5a2f6b,line:'Hendeğe düşen ben olmayacağım, merak etme.'},
  {nick:'Kara Tren',name:'Serkan Raycı',car:'charger',col:0x16171a,line:'Rayda da asfaltta da önümde durulmaz.'},
  {nick:'Gölge',name:'Mert Karabulut',car:'evo',col:0x16171a,line:'Beni dikiz aynasında bir kere görürsün. Sonra hiç.'},
  {nick:'Profesör',name:'Ercan Hoca',car:'audi',col:0x8a8f96,line:'Yarış matematiktir evladım. Sen daha toplama yapıyorsun.'},
  {nick:'Sultan',name:'Selin Aydemir',car:'bmw',col:0xc11c22,line:'Bu mahallenin tacı bende. Vermeye hiç niyetim yok.'},
  {nick:'Kaptan',name:'Volkan Akyazılı',car:'supra',col:0xeceef0,line:'Bu şehrin virajlarını ben çizdim, sen sadece sürüyorsun.'},
  {nick:'Kartal',name:'Cengiz Sakaryalı',car:'r34',col:0x1a3a8a,line:'Kartal yükseklerden uçar. Gel de yakala.'}];
 BL.forEach(function(r,i){r.rank=15-i;r.tier=i});
  // jenerik sokak yarışçıları (ilçe lakapları)
 var CREW=['Serdivanlı','Arifiyeli','Geyveli Cem','Pamukovalı','Karasulu Ali','Kaynarcalı','Söğütlü Murat','Taraklı','Akyazılı Uğur','Ferizlili Can','Karapürçekli','Adalı Barış',
  'Turbo Hasan','Bıçkın','Dizel Nuri','Şimşek','Pırpır','Kıvılcım','Yağmur','Sis','Kuzgun','Bozkurt','Rüzgâr','Çakır','Gece Kuşu','Tilki','Lastik Cemal','Kırmızı Şimşek'];
 var NAMES={mithatpasa:['Mithatpaşa','Cami Önü','Çarşı Arkası','Tren Yolu','Okul Yolu','Fırın Köşesi','Pazar Yeri','Dere Boyu','Mahalle Arası','Bakkal Köşesi'],
  liman:['Sahil Yolu','Liman','Tünel','Otoyol','Park Yolu','Fener','Rıhtım','Köprü Altı'],
  sapanca:['Sapanca','Göl Kenarı','O-4','Otoyol','Gişeler','Viyadük','Kırkpınar','Bariyer']};
 var SUF={circuit:['Turu','Döngüsü','Gece Devresi','Kapışması'],sprint:['Sprinti','Kaçışı','Hattı','Düzlüğü'],elim:['Elemesi','Ayıklaması','Son Kalan'],speed:['Radarı','Hız Kapanı','Flaşı'],lap:['Tur Rekoru','Kronometre','Saat Avı']};
 var BOSSMAP={4:'liman',5:'liman',6:'liman',7:'sapanca',8:'liman',9:'sapanca',11:'liman',12:'sapanca',13:'liman'}; // #8 'Sapanca' lakaplı rakip kendi otoyolunda (sprint)
 var EV=[],seq=['circuit','sprint','elim','speed','lap'];
 function pick(a,k){return a[k%a.length]}
 for(var t=0;t<15;t++){
  var nR=Math.min(7,3+Math.floor(t/2)),prize=2000+t*900,fame=120+t*15;
  // harita dağılımı: ilk 4 halka tamamen Mithatpaşa; sonrasında her halkada 1 Sapanca (sprint/hız kapanı/devre), 1 Liman, 1 Mithatpaşa
  var ks=-1,kl=-1;if(t>=4){['speed','sprint','circuit'].forEach(function(w){for(var q=0;q<3&&ks<0;q++)if(seq[(t*2+q)%5]===w)ks=q});
   for(var q2=2;q2>=0;q2--)if(q2!==ks){kl=q2;break}}
  for(var k=0;k<3;k++){
   var type=seq[(t*2+k)%5],map=k===ks?'sapanca':k===kl?'liman':'mithatpasa',night=((t*3+k)%5)!==2?1:0;
   var e={id:'t'+t+'e'+k,tier:t,map:map,type:type,n:nR-(k===1?1:0),night:night,prize:Math.round(prize*(k===2?1.2:1)/100)*100,fame:Math.round(fame*(k===2?1.15:1)),traffic:night?5:7};
   if(type==='circuit'){e.laps=t<8?2:3}
   else if(type==='sprint'){e.a=((t*37+k*13)%100)/100;e.dist=1.1+((t+k)%4)*.2}
   else if(type==='elim'){e.n=Math.max(3,e.n);e.seg=e.n>4?.5:1}
   else if(type==='speed'){e.laps=1;e.dist=1+(t%3)*.25;e.radars=3+(t%3);e.a=((t*53+k*7)%100)/100}
   else if(type==='lap'){e.laps=3;e.n=Math.min(e.n,5)}
   e.name=pick(NAMES[map],t*3+k)+' '+pick(SUF[type],t+k);
   EV.push(e)}
  var b=BL[t],bm=BOSSMAP[t]||'mithatpasa';b.boss={id:'boss'+t,tier:t,boss:1,map:bm,type:t===7?'sprint':(t%2===0)?(t%4===0?'sprint':'circuit'):(t%4===3?'elim':'circuit'),n:(t%2===0)?1:Math.min(7,3+Math.floor(t/3)),night:1,
   prize:6000+t*2500,fame:300+t*40,traffic:4,laps:t<9?2:3,a:((t*29)%100)/100,dist:1.4,name:'#'+b.rank+' '+b.nick+' ile kapışma'};
  b.cash=5000+t*3500;b.req={wins:2,fame:(t+1)*(220+14*t),esc:t>=4?Math.floor((t-2)/2):0}}
 // parça kilitleri: yükseltme seviyesi -> gereken yenilen rakip sayısı
 var UPLOCK=[0,2,6];
 var START_CARS=['evo','astra','dogan','murat'];
 return {MAPS:MAPS,TYPES:TYPES,BL:BL,EV:EV,CREW:CREW,UPLOCK:UPLOCK,START:START_CARS}})();
